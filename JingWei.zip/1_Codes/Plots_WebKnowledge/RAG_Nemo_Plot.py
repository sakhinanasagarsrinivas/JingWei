import json
import numpy as np
import matplotlib.pyplot as plt

# Load data from a JSON file
with open('/content/combinedData.json', 'r') as file:
    data = json.load(file)

# Define the score metrics to analyze
score_metrics = ["helpfulness", "correctness", "coherence", "complexity", "verbosity"]

# Initialize a dictionary to store scores for each metric
scores = {metric: [] for metric in score_metrics}

# Parse the JSON data and extract scores for each metric
for entry in data:
    entry_scores = entry.get("scores", "")  # Get the "scores" string from the JSON entry
    for metric in score_metrics:
        try:
            # Extract the score value for the given metric
            score_value = float(entry_scores.split(f"{metric}:")[1].split(",")[0])
            scores[metric].append(score_value)
        except (IndexError, ValueError):
            # Skip if the score format is incorrect or missing
            continue

# Calculate mean and standard deviation for each metric
means = [np.mean(scores[metric]) for metric in score_metrics]
std_devs = [np.std(scores[metric]) for metric in score_metrics]

# Set up positions for the bars in the bar plot
x = np.arange(len(score_metrics))  # Positions of the bars

# Create a new figure and axes for the plot
fig, ax = plt.subplots(figsize=(8, 5))

# Define a professional color palette for the bars
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

# Plot the bar chart with error bars (standard deviation)
bars = ax.bar(x, means, yerr=std_devs, capsize=6, color=colors, alpha=0.85, edgecolor='black')

# Customize the y-axis label
ax.set_ylabel("Scores", fontsize=18, fontweight='bold', labelpad=20)

# Customize the x-axis ticks and labels
ax.set_xticks(x)
ax.set_xticklabels(score_metrics, fontsize=14, fontweight='bold', rotation=15, ha='right')

# Customize the y-axis ticks
ax.tick_params(axis='y', labelsize=14, labelcolor='black', width=1.2)

# Add a grid to the y-axis for better readability
ax.yaxis.grid(True, linestyle='--', alpha=0.7)

# Remove the top and right spines for a cleaner appearance
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Annotate each bar with its mean value
for bar, mean in zip(bars, means):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width() / 2.0, height + 0.1, f'{mean:.2f}', ha='center', fontsize=10)

# Optimize layout and save the plot as a PDF
plt.tight_layout()
plt.savefig("score_metrics_plot.pdf", format='pdf')

# Display the plot
plt.show()
