import os
import json
import shutil
from openai import OpenAI

# Retrieve and set the Nvidia API Key from user data
Nvidia_API_Key = userdata.get('Nvidia_API_Key')  # Assuming `userdata` provides the API Key
os.environ["Nvidia_API_Key"] = Nvidia_API_Key  # Store it as an environment variable

# Initialize the OpenAI client for Nvidia's API integration
client = OpenAI(
    base_url="https://integrate.api.nvidia.com/v1",
    api_key=os.environ['Nvidia_API_Key']  # Access the API key from environment variables
)

# Define the input and output folders
input_folder = '/content/json_files'  # Folder containing input JSON files
output_folder = '/content/scored_json_files'  # Folder to save processed and scored JSON files

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Initialize an error log to capture processing issues
error_log = []

# Process each JSON file in the input folder
for file_name in os.listdir(input_folder):
    # Only process files with a .json extension
    if file_name.endswith('.json'):
        input_file_path = os.path.join(input_folder, file_name)
        output_file_path = os.path.join(output_folder, f'scored_{file_name}')

        try:
            # Load the JSON file
            with open(input_file_path, 'r') as file:
                data = json.load(file)

            # Extract required fields from the JSON file
            chemical_name = data.get('chemical_name', '')  # Retrieve the chemical name, if available
            question = data.get('Question', '')           # Retrieve the question field
            answer = data.get('Answer', '')               # Retrieve the answer field

            # Skip files missing critical fields
            if not question or not answer:
                print(f"Skipping file {file_name} due to missing 'Question' or 'Answer'.")
                continue

            # Prepare the messages for the Nemotron model API call
            messages = [
                {"role": "user", "content": question},
                {"role": "assistant", "content": answer}
            ]

            # Call the Nemotron model to retrieve scores
            completion = client.chat.completions.create(
                model="nvidia/nemotron-4-340b-reward",
                messages=messages
            )

            # Extract scores from the API response
            scores_message = completion.choices[0].message[0].content  # Adjust to actual API response structure
            scores = scores_message.strip()  # Clean up whitespace, if necessary

            # Construct the result dictionary
            scores_list = {
                "chemical_name": chemical_name,
                "question": question,
                "answer": answer,
                "scores": scores
            }

            # Save the results to a new JSON file in the output folder
            with open(output_file_path, 'w') as output_file:
                json.dump(scores_list, output_file, indent=4)

            print(f"Successfully processed and scored: {file_name}")

        except Exception as e:
            # Capture and log any errors encountered during processing
            error_log.append({"file": file_name, "error": str(e)})
            print(f"Error processing file {file_name}: {e}")

# Save the error log to a file for debugging purposes, if there were errors
if error_log:
    with open(os.path.join(output_folder, 'error_log.json'), 'w') as error_file:
        json.dump(error_log, error_file, indent=4)

    print("Some files encountered errors. Check 'error_log.json' in the output folder.")

# Compress the output folder containing scored JSON files into a ZIP archive
folder_to_zip = '/content/scored_json_files'  # Path to the folder to be zipped
zip_file_name = 'scored_json_files.zip'      # Name of the ZIP file
shutil.make_archive(zip_file_name.replace('.zip', ''), 'zip', folder_to_zip)

# Function to combine multiple JSON files into a single JSON file
def combine_json_files(folder_path, output_file):
    combined_data = []

    # Iterate through all JSON files in the specified folder
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.json'):
            file_path = os.path.join(folder_path, file_name)
            try:
                # Load and append data from each JSON file
                with open(file_path, 'r') as file:
                    data = json.load(file)
                    combined_data.append(data)
            except Exception as e:
                print(f"Error reading {file_name}: {e}")

    # Write the combined data to a single JSON file
    with open(output_file, 'w') as output:
        json.dump(combined_data, output, indent=4)
    print(f"Combined JSON saved to {output_file}")

# Combine JSON files from a folder into a single JSON file
folder_path = '/content/CombinedJSON'  # Path to the folder with JSON files
output_file = '/content/combined.json'  # Path to save the combined JSON file
combine_json_files(folder_path, output_file)

# Compress the combined JSON file folder into a ZIP archive
shutil.make_archive(zip_file_name.replace('.zip', ''), 'zip', folder_to_zip)
