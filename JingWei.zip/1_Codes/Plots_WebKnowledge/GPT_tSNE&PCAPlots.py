# !pip install openai==0.28 PyMuPDF kneed

import os
import fitz
import openai
import numpy as np
from kneed import KneeLocator
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

OPENAI_API_KEY = userdata.get("OpenAI_API_Key")
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
openai.api_key = OPENAI_API_KEY

pdf_folder = r'/content/drive/MyDrive/Project 1/FinalData/GPT_PDF'
pdf_embeddings = []

# Function to generate GPT embeddings
def get_gpt_embedding(text):
    """
    Generate an embedding for the given text using OpenAI's text-embedding-3-small model.
    
    Args:
        text (str): Input text to be embedded.
    
    Returns:
        list: A vector representing the embedding of the input text.
    """
    response = openai.Embedding.create(
        input=text,
        model="text-embedding-3-small"
    )
    return response['data'][0]['embedding']

# Initialize variables
pdf_folder = "path/to/pdf_folder"  # Folder containing PDF files
pdf_embeddings = []  # List to store embeddings for all PDFs

# Process each PDF file in the folder
for pdf_file in os.listdir(pdf_folder):
    if pdf_file.endswith('.pdf'):
        pdf_path = os.path.join(pdf_folder, pdf_file)
        text = ""  # Initialize an empty string to hold the text for the entire PDF
        with fitz.open(pdf_path) as doc:
            for page in doc:
                text += page.get_text()  # Concatenate text from all pages
        embedding = get_gpt_embedding(text)  # Convert the entire PDF text to an embedding
        pdf_embeddings.append(embedding)  # Store the embedding

# Dimensionality reduction using PCA
pca = PCA(n_components=2)
pca_result = pca.fit_transform(pdf_embeddings)

# Determine t-SNE perplexity based on sample size
n_samples = len(pdf_embeddings)
perplexity_value = max(5, min(n_samples // 3, 50))  # Set perplexity dynamically

# Dimensionality reduction using t-SNE
tsne = TSNE(n_components=2, perplexity=perplexity_value, n_iter=1000, random_state=42)
tsne_result = tsne.fit_transform(pca_result)

# Visualization of PCA and t-SNE
plt.figure(figsize=(16, 8))

# PCA Visualization
plt.subplot(1, 2, 1)
plt.scatter(pca_result[:, 0], pca_result[:, 1], cmap='viridis')
plt.title('PCA of PDF Embeddings')

# t-SNE Visualization
plt.subplot(1, 2, 2)
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], cmap='viridis')
plt.title('t-SNE of PDF Embeddings')

plt.show()

# Clustering with K-means
max_clusters = min(10, n_samples)  # Ensure max clusters do not exceed sample size
sse = []  # List to store Sum of Squared Errors (SSE)

# Elbow Method to determine optimal k
for k in range(1, max_clusters + 1):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(pdf_embeddings)
    sse.append(kmeans.inertia_)

# Plot SSE for Elbow Method
plt.plot(range(1, max_clusters + 1), sse)
plt.xlabel('Number of Clusters')
plt.ylabel('SSE')
plt.title('Elbow Method For Optimal k')
plt.show()

# Determine the optimal number of clusters using KneeLocator
kl = KneeLocator(range(1, max_clusters + 1), sse, curve="convex", direction="decreasing")
optimal_k = kl.elbow
print(f"Optimal number of clusters: {optimal_k}")

# Fit K-means using the optimal number of clusters
kmeans = KMeans(n_clusters=optimal_k, random_state=42)
clusters = kmeans.fit_predict(pdf_embeddings)

# t-SNE Scatter Plot with Clusters
plt.figure(figsize=(12, 10))
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c=clusters, cmap='viridis', s=50, alpha=1)
plt.title('t-SNE with K-means Clusters', fontsize=20, fontweight='bold')
plt.xlabel('t-SNE Dimension 1', fontsize=18, fontweight='bold')
plt.ylabel('t-SNE Dimension 2', fontsize=18, fontweight='bold')
plt.tight_layout()
plt.savefig('gpt_tsne_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()

# PCA Scatter Plot with Clusters
plt.figure(figsize=(12, 10))
plt.scatter(pca_result[:, 0], pca_result[:, 1], c=clusters, cmap='viridis', s=50, alpha=1)
plt.title('PCA with K-means Clusters', fontsize=20, fontweight='bold')
plt.xlabel('Principal Component 1', fontsize=18, fontweight='bold')
plt.ylabel('Principal Component 2', fontsize=18, fontweight='bold')
plt.tight_layout()
plt.savefig('gpt_pca_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()