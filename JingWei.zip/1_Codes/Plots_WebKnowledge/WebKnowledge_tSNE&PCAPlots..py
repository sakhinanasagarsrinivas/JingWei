# !pip install openai==0.28 PyMuPDF kneed

import os
import fitz
import openai
import numpy as np
from kneed import KneeLocator
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# Load the OpenAI API key from user data and set it as an environment variable
# OPENAI_API_KEY: Securely fetches the API key from a user-defined data source.
# The API key is used to authenticate requests to the OpenAI API.
OPENAI_API_KEY = userdata.get("OpenAI_API_Key")
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
openai.api_key = OPENAI_API_KEY

# Path to the folder containing PDF files
# pdf_folder: Directory path where all PDFs to be processed are stored.
pdf_folder = r'/content/drive/MyDrive/Project 1/FinalData/AllCombined'

# List to store embeddings for all PDF files
# pdf_embeddings: Stores vector representations of PDF content generated using GPT embeddings.
pdf_embeddings = []

# Function to generate GPT embeddings for a given text
# get_gpt_embedding: Sends a request to the OpenAI API to generate embeddings for the input text.
# Parameters:
#   text (str): Text input for which the embedding is generated.
# Returns:
#   embedding (list): A vector representation of the text.
def get_gpt_embedding(text):
    response = openai.Embedding.create(
        input=text,
        model="text-embedding-3-small"
    )
    return response['data'][0]['embedding']

# Iterate through all PDF files in the specified folder
# Extract text from each PDF, generate embeddings, and store them.
for pdf_file in os.listdir(pdf_folder):
    if pdf_file.endswith('.pdf'):
        pdf_path = os.path.join(pdf_folder, pdf_file)
        text = ""  # Initialize an empty string to hold the text for the entire PDF
        with fitz.open(pdf_path) as doc:  # Open the PDF file using PyMuPDF
            for page in doc:
                text += page.get_text()  # Concatenate text from all pages
        embedding = get_gpt_embedding(text)  # Convert the entire PDF text to an embedding
        pdf_embeddings.append(embedding)  # Store the embedding

# Dimensionality reduction using PCA
# PCA is used to reduce the dimensionality of embeddings for better visualization.
pca = PCA(n_components=2)
pca_result = pca.fit_transform(pdf_embeddings)

# Calculate the perplexity value dynamically based on the number of samples
# Perplexity impacts the t-SNE clustering and visualization.
n_samples = len(pdf_embeddings)
perplexity_value = max(5, min(n_samples // 3, 50))

# Dimensionality reduction using t-SNE
# t-SNE is applied to the PCA result for clustering visualization in a 2D space.
tsne = TSNE(n_components=2, perplexity=perplexity_value, max_iter=1000, random_state=42)
tsne_result = tsne.fit_transform(pca_result)

# Plot PCA and t-SNE visualizations
# Visualize the embeddings in 2D space to analyze clustering.
plt.figure(figsize=(16, 8))

# PCA visualization
plt.subplot(1, 2, 1)
plt.scatter(pca_result[:, 0], pca_result[:, 1], cmap='viridis')
plt.title('PCA of PDF Embeddings')

# t-SNE visualization
plt.subplot(1, 2, 2)
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], cmap='viridis')
plt.title('t-SNE of PDF Embeddings')

plt.show()

# Determine the optimal number of clusters using the Elbow Method
# Maximum clusters are capped based on the number of samples.
max_clusters = min(10, n_samples)

# Use the Elbow Method to find the optimal k for K-Means clustering
sse = []
for k in range(1, max_clusters + 1):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(pdf_embeddings)
    sse.append(kmeans.inertia_)

# Plot the Elbow graph to visualize the optimal number of clusters
plt.plot(range(1, max_clusters + 1), sse)
plt.xlabel('Number of clusters')
plt.ylabel('SSE')
plt.title('Elbow Method For Optimal k')
plt.show()

# Use the KneeLocator to determine the optimal k
# KneeLocator identifies the 'elbow' point in the SSE graph.
kl = KneeLocator(range(1, max_clusters + 1), sse, curve="convex", direction="decreasing")
optimal_k = kl.elbow
print(f"Optimal number of clusters: {optimal_k}")

# Scatter plot with K-means clusters on t-SNE visualization
plt.figure(figsize=(12, 10))
scatter = plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c=clusters, cmap='viridis', s=50, alpha=1)
plt.title('t-Distributed Stochastic Neighbor Embedding', fontsize=20, fontweight='bold')
plt.xlabel('t-SNE Dimension 1', fontsize=18, fontweight='bold', labelpad=20)
plt.ylabel('t-SNE Dimension 2', fontsize=18, fontweight='bold', labelpad=20)
plt.xlim(-40, 50)
plt.ylim(-40, 30)
plt.grid(False)
plt.tight_layout()
plt.savefig('rag_tsne_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()

# Scatter plot with K-means clusters on PCA visualization
plt.figure(figsize=(12, 10))
plt.scatter(pca_result[:, 0], pca_result[:, 1], c=clusters, cmap='viridis', s=50, alpha=1)
plt.xlim(-0.4, 0.5)
plt.ylim(-0.4, 0.4)
plt.title('Principal Component Analysis', fontsize=20, fontweight='bold')
plt.xlabel('Principal Component 1', fontsize=18, fontweight='bold', labelpad=20)
plt.ylabel('Principal Component 2', fontsize=18, fontweight='bold', labelpad=20)
plt.savefig('rag_pca_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()

