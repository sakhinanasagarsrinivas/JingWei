# !pip install PyMuPDF openai==0.28

import os
import re
import fitz
import openai
import time
import numpy as np
import matplotlib.pyplot as plt

# Set up the OpenAI API Key from user data and environment variables
OPENAI_API_KEY = userdata.get("OpenAI_API_Key")
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY  # Set the API key as an environment variable
openai.api_key = OPENAI_API_KEY  # Initialize the OpenAI API key

# Define file paths for different model-generated PDF directories
rag = r"/content/RAG_PDF"  # Directory for PDFs generated using Gemini
gpt = r"/content/GPT_PDF"  # Directory for PDFs generated using GPT
anthropic = r"/content/Anthropic_PDF"  # Directory for PDFs generated using Anthropic

def read_pdf_content(pdf_path):
    """
    Reads the content of a PDF file and returns it as a single string.

    Args:
        pdf_path (str): The file path of the PDF document to read.

    Returns:
        str: The textual content of the PDF.
    """
    content = ''
    with fitz.open(pdf_path) as pdf:  # Open the PDF file
        for page in pdf:  # Iterate through each page in the PDF
            content += page.get_text()  # Extract and append text content of the page
    return content

def get_embedding(content, max_retries=3, backoff_factor=2):
    """
    Generates an embedding for the provided text content using OpenAI's API.
    Incorporates retry logic with exponential backoff for robustness.

    Args:
        content (str): The text content to generate the embedding for.
        max_retries (int): Maximum number of retry attempts for API call failures.
        backoff_factor (int): The exponential backoff factor for retry delays.

    Returns:
        np.array: A NumPy array containing the embedding vector.

    Raises:
        openai.error.OpenAIError: If the API encounters an error after retries.
    """
    for attempt in range(max_retries):
        try:
            # Make an API call to generate embeddings
            response = openai.Embedding.create(
                input=content,  # Input text for embedding
                model="text-embedding-3-small",  # Embedding model
                request_timeout=60  # Timeout for API request
            )
            return np.array(response['data'][0]['embedding'])  # Convert to NumPy array
        except openai.error.Timeout as e:
            print(f"Timeout error on attempt {attempt + 1}/{max_retries}: {e}")
            if attempt < max_retries - 1:
                time.sleep(backoff_factor ** attempt)  # Apply exponential backoff
            else:
                raise  # Re-raise the error after exhausting retries
        except openai.error.OpenAIError as e:
            print(f"OpenAI API error: {e}")
            raise  # Raise the error for further handling

def clean_pdf_name(pdf_name):
    """
    Cleans a PDF file name by removing special characters and text within brackets.

    Args:
        pdf_name (str): The original name of the PDF file.

    Returns:
        str: The cleaned name, converted to lowercase and stripped of whitespace.
    """
    # Remove text enclosed in brackets or parentheses
    cleaned_name = re.sub(r'\[.*?\]|\(.*?\)', '', pdf_name)
    # Remove all special characters except word characters and spaces
    cleaned_name = re.sub(r'[^\w\s]', '', cleaned_name)
    return cleaned_name.strip().lower()  # Convert to lowercase and remove extra spaces

def find_matching_pdf(pdf_name, folder):
    """
    Searches for a PDF in the specified folder that matches the cleaned name of the given PDF.

    Args:
        pdf_name (str): The name of the PDF to search for.
        folder (str): The folder path to search within.

    Returns:
        str or None: The full file path of the matching PDF, or None if no match is found.
    """
    cleaned_name = clean_pdf_name(pdf_name)  # Clean the input PDF name
    for file in os.listdir(folder):  # Iterate through all files in the folder
        if file.endswith('.pdf') and clean_pdf_name(file) == cleaned_name:
            # Return the full path of the matching PDF
            return os.path.join(folder, file)
    return None  # Return None if no match is found

def calculate_embedding_similarity(embedding1, embedding2):
    """
    Calculates the cosine similarity between two embedding vectors.

    Args:
        embedding1 (np.array): The first embedding vector.
        embedding2 (np.array): The second embedding vector.

    Returns:
        float: The cosine similarity value between the two embeddings, ranging from -1 to 1.
               Returns 0.0 if either of the embeddings has a norm of zero to prevent division by zero.
    """
    dot_product = np.dot(embedding1, embedding2)  # Compute the dot product
    norm_embedding1 = np.linalg.norm(embedding1)  # Compute the norm of the first embedding
    norm_embedding2 = np.linalg.norm(embedding2)  # Compute the norm of the second embedding

    # Prevent division by zero
    if norm_embedding1 == 0 or norm_embedding2 == 0:
        return 0.0

    # Return cosine similarity
    return dot_product / (norm_embedding1 * norm_embedding2)

def normalize_distances(distances):
    """
    Normalizes a list of distance values to be within the range [0, 1].

    Args:
        distances (list): A list of distance values.

    Returns:
        list: A list of normalized distance values, scaled to the range [0, 1].
    """
    min_distance = min(distances)  # Find the minimum distance
    max_distance = max(distances)  # Find the maximum distance
    # Normalize distances to the range [0, 1]
    return [(d - min_distance) / (max_distance - min_distance) for d in distances]

def plot_differences(differences_llm1_vs_llm2, differences_llm1_vs_llm3):
    """
    Plots the differences in embedding similarities using a box-and-whisker plot.

    Args:
        differences_llm1_vs_llm2 (list): List of similarity differences between LLM 1 and LLM 2.
        differences_llm1_vs_llm3 (list): List of similarity differences between LLM 1 and LLM 3.

    Output:
        Saves the plot as a PDF file named 'EmbeddingSimilarity.pdf' and displays it.
    """
    plt.figure(figsize=(12, 8))  # Adjust figure size for better visualization

    # Create the boxplot
    plt.boxplot(
        [differences_llm1_vs_llm2, differences_llm1_vs_llm3], 
        labels=['GPT-4o', 'Anthropic-Haiku']
    )

    # Add professional formatting for the plot
    plt.ylabel('Embedding Similarities', labelpad=20, fontsize=18, fontweight="bold")
    plt.xticks(fontsize=14, fontweight="bold")
    plt.yticks(fontsize=14, fontweight="bold")

    # Save the plot as a PDF
    plt.tight_layout()
    plt.savefig('EmbeddingSimilarity.pdf', format='pdf', bbox_inches='tight')

    # Display the plot
    plt.show()

# List all PDF files in the first folder (LLM 1)
pdf_files_folder1 = [f for f in os.listdir(rag) if f.endswith('.pdf')]
differences_llm1_vs_llm2 = []  # List to store differences between LLM 1 and LLM 2
differences_llm1_vs_llm3 = []  # List to store differences between LLM 1 and LLM 3

for pdf_name in pdf_files_folder1:
    pdf_path_folder1 = os.path.join(rag, pdf_name)

    # Find matching PDFs in the folders for LLM 2 and LLM 3
    matching_pdf_folder2 = find_matching_pdf(pdf_name, gpt)
    matching_pdf_folder3 = find_matching_pdf(pdf_name, anthropic)

    # Skip if no matches are found in both folders
    if not matching_pdf_folder2 and not matching_pdf_folder3:
        continue

    # If a match is found in folder 2
    if matching_pdf_folder2:
        # Read content and generate embeddings for LLM 1 and LLM 2
        content1 = read_pdf_content(pdf_path_folder1)
        content2 = read_pdf_content(matching_pdf_folder2)

        embedding1 = get_embedding(content1)
        embedding2 = get_embedding(content2)

        # Calculate and store similarity difference
        difference_llm1_vs_llm2 = calculate_embedding_similarity(embedding1, embedding2)
        differences_llm1_vs_llm2.append(difference_llm1_vs_llm2)

    # If a match is found in folder 3
    if matching_pdf_folder3:
        # Read content and generate embeddings for LLM 1 and LLM 3
        content1 = read_pdf_content(pdf_path_folder1)
        content3 = read_pdf_content(matching_pdf_folder3)

        embedding1 = get_embedding(content1)
        embedding3 = get_embedding(content3)

        # Calculate and store similarity difference
        difference_llm1_vs_llm3 = calculate_embedding_similarity(embedding1, embedding3)
        differences_llm1_vs_llm3.append(difference_llm1_vs_llm3)

# Normalize the similarity differences for better comparison
normalized_differences_llm1_vs_llm2 = normalize_distances(differences_llm1_vs_llm2)
normalized_differences_llm1_vs_llm3 = normalize_distances(differences_llm1_vs_llm3)

# Plot the normalized differences using a box and whisker plot
plot_differences(normalized_differences_llm1_vs_llm2, normalized_differences_llm1_vs_llm3)


def plot_individual_histograms(similarities1, similarities2):
    """
    Plots two separate histograms comparing similarity scores against frequency for two sets of data.

    Args:
        similarities1 (list): List of similarity scores for comparison between Gemini and GPT-4o.
        similarities2 (list): List of similarity scores for comparison between Gemini and Anthropic.

    Output:
        Saves two histograms as PDF files and displays them:
        - 'RAG_vs_GPT-4o_Histogram.pdf' for Gemini vs. GPT-4o similarity scores.
        - 'RAG_vs_Anthropic_Histogram.pdf' for Gemini vs. Anthropic similarity scores.
    """
    # Plot for Gemini vs GPT-4o
    plt.figure(figsize=(10, 6))  # Set figure size for better visualization
    plt.hist(
        similarities1, 
        bins=20, 
        alpha=0.85, 
        color='blue', 
        edgecolor='black'  # Add edges to bins for clarity
    )
    plt.xlabel('Similarity Scores', fontsize=18, fontweight="bold", labelpad=20)  # X-axis label
    plt.ylabel('Frequency', fontsize=18, fontweight="bold", labelpad=20)  # Y-axis label
    # plt.title('Gemini vs GPT-4o Similarity Scores', fontsize=20, fontweight="bold", pad=15)
    plt.xticks(fontsize=14, fontweight="bold")  # Format x-axis ticks
    plt.yticks(fontsize=14, fontweight="bold")  # Format y-axis ticks
    plt.ylim(0, 400)  # Set y-axis limit for clarity
    # Adjust visibility of spines for professional formatting
    plt.gca().spines['top'].set_visible(True)
    plt.gca().spines['right'].set_visible(True)
    plt.tight_layout()  # Optimize layout to prevent overlap
    plt.savefig('RAG_vs_GPT-4o_Histogram.pdf', format='pdf', bbox_inches='tight')  # Save plot as PDF
    plt.show()  # Display the plot

    # Plot for Gemini vs Anthropic
    plt.figure(figsize=(10, 6))  # Set figure size for the second histogram
    plt.hist(
        similarities2, 
        bins=20, 
        alpha=0.85, 
        color='orange', 
        edgecolor='black'  # Add edges to bins for clarity
    )
    plt.xlabel('Similarity Scores', fontsize=18, fontweight="bold", labelpad=20)  # X-axis label
    plt.ylabel('Frequency', fontsize=18, fontweight="bold", labelpad=20)  # Y-axis label
    # plt.title('Gemini vs Anthropic Similarity Scores', fontsize=20, fontweight="bold", pad=15)
    plt.xticks(fontsize=14, fontweight="bold")  # Format x-axis ticks
    plt.yticks(fontsize=14, fontweight="bold")  # Format y-axis ticks
    plt.ylim(0, 350)  # Set y-axis limit for clarity
    # Adjust visibility of spines for professional formatting
    plt.gca().spines['top'].set_visible(True)
    plt.gca().spines['right'].set_visible(True)
    plt.tight_layout()  # Optimize layout to prevent overlap
    plt.savefig('RAG_vs_Anthropic_Histogram.pdf', format='pdf', bbox_inches='tight')  # Save plot as PDF
    plt.show()  # Display the plot

# Call the function with normalized differences
plot_individual_histograms(normalized_differences_llm1_vs_llm2, normalized_differences_llm1_vs_llm3)



