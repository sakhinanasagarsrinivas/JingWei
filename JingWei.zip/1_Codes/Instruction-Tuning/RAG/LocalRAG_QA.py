
############ pip install --upgrade openai llama-index llama-index-agent-openai llama-index-embeddings-openai llama-index-llms-openai llama-index-multi-modal-llms-openai llama-index-program-openai llama-index-question-gen-openai

import json
import logging
import os
import typing as t
from typing import List
from openai import OpenAI
from datasets import Dataset
from requests.exceptions import ConnectionError, Timeout, RequestException

# Set OpenAI API key
openai_client = OpenAI(api_key="")
nvidia_client = OpenAI(base_url = "https://integrate.api.nvidia.com/v1", api_key = "")  

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import necessary modules from llama_index
from llama_index.core import SimpleDirectoryReader
from llama_index.core.llms import ChatMessage
from llama_index.llms.openai import OpenAI

DEFAULT_CHUNK_SIZE = 8192

def evaluate_answer_with_context_in_prompt(model, question, context, answer):
    """
    Evaluates a generated answer by embedding the retrieved context directly into the prompt
    and instructing the reward model to evaluate the quality of the response based on the question
    and the provided context. Includes error handling for API calls.
    
    Args:
        client (OpenAI): The OpenAI client used for API calls.
        model (str): The model to be used for scoring the response.
        question (str): The original question.
        context (str): The retrieved context relevant to the question.
        response_content (str): The generated response content.

    Returns:
        dict: A dictionary containing the response content, scores, and context, or None if an error occurs.
    """
    
    # Combine the context with the question and add an instruction to the prompt
    question_with_context = (
        f"Context: {context}\n\n"
        f"Question: {question}\n\n"
        "Instruction: Assess the response based on how accurately it answers the question and how well the information is grounded in the provided context."
    )

    # Create the messages payload with the combined prompt
    messages = [
        {"role": "user", "content": question_with_context},
        {"role": "assistant", "content": answer},
    ]
    try:
        # Send the combined prompt and response to the model and get the response
        response = nvidia_client.chat.completions.create(model=model, messages=messages)
        
        # Extract log probabilities from the response
        logprobs = response.choices[0].logprobs.content
        score_dict = {score.token: score.logprob for score in logprobs}
        
        # Return the response content, context, and scores
        return {"scores": score_dict}
    
    except Exception as e:
        # Error handling: Log the error and return None
        print(f"Error evaluating answer with context in prompt: {e}")
        return None

class SimplifiedRAFTDataset:
    """Simplified RAFT Dataset Generator.

    This class is responsible for generating a dataset of question-answer pairs from text chunks
    extracted from PDF files. It uses a Large Language Model (LLM) to generate the questions
    and answers based on the content of the text chunks.

    Attributes:
        directory_path (str): Path to the directory containing PDF files.
        output_file (str): Path to the output JSON file where the generated dataset will be saved.
        chunk_size (int): Size of the text chunks to be generated from the PDF files.
        llm (OpenAI): Large Language Model instance for generating questions and answers.
        data (list): List of generated question-answer pairs with ratings.
    """

    def __init__(self, directory_path: str, output_file: str, llm=None, chunk_size=DEFAULT_CHUNK_SIZE):
        """Initializes the SimplifiedRAFTDataset with directory path, output file, and LLM."""
        self.directory_path = directory_path
        self.output_file = output_file
        self.chunk_size = chunk_size
        self.data = []

    def get_chunks(self, file_path: str, chunk_size: int) -> List[str]:
        """Reads a document and splits it into chunks of specified size.

        Args:
            file_path (str): Path to the PDF file.
            chunk_size (int): Size of each text chunk.

        Returns:
            List[str]: List of text chunks.
        """
        documents = SimpleDirectoryReader(input_files=[file_path]).load_data()
        chunks = []
        for doc in documents:
            text = doc.get_content()
            # Simple chunking based on fixed size
            for i in range(0, len(text), chunk_size):
                chunks.append(text[i:i + chunk_size])
        return chunks

    def generate_questions(self, chunk: str, num_questions: int = 1) -> List[str]:
        """Generates questions for a given chunk of text.

        Args:
            chunk (str): The text chunk to generate questions from.
            num_questions (int): Number of questions to generate.

        Returns:
            List[str]: List of generated questions.
        """
        prompt = f"""
        Generate exactly {num_questions} clear, concise, and fact-based questions that can be answered solely using the information provided in the following text. Ensure that the questions are directly relevant to the content and avoid any ambiguity or assumptions. Each question should target a distinct piece of information from the text, ensuring no overlap in the questions generated. The questions must adhere strictly to the provided text and should not introduce any outside information.
        \n{chunk}
        """
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a question generator."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                top_p=0.7,
                max_tokens=4096,
            )
            questions_text = response.choices[0].message.content
            questions = questions_text.split("\n")
            return [q.strip() for q in questions if q.strip()]
        
        except ConnectionError as e:
            logger.error(f"Network error while generating questions: {e}")
            raise
        except Timeout as e:
            logger.error(f"Request timed out while generating questions: {e}")
            raise
        except RequestException as e:
            logger.error(f"An error occurred during the request: {e}")
            raise

    def generate_answer(self, question: str, chunk: str) -> str:
        """Generates an answer to the given question using the chunk of text.

        Args:
            question (str): The question to answer.
            chunk (str): The text chunk used to generate the answer.

        Returns:
            str: The generated answer.
        """
        prompt = f"""
        Question: {question}
        \nContext: {chunk}
        \nProvide a concise, accurate, and fact-based answer to the question, using only the information available in the context provided. The answer must be directly derived from the context and should not include any external knowledge, speculation, or interpretation. Ensure that the response is precise and strictly adheres to the content of the context without introducing any additional information.
        """
       
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a question answerer."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                top_p=0.7,
                max_tokens=4096,
            )
            return response.choices[0].message.content
        
        except ConnectionError as e:
            logger.error(f"Network error while generating the answer: {e}")
            raise
        except Timeout as e:
            logger.error(f"Request timed out while generating the answer: {e}")
            raise
        except RequestException as e:
            logger.error(f"An error occurred during the request: {e}")
            raise

    def critique(self, question: str, answer: str, context: str) -> t.Dict[str, int]:
        """Rates the answer to a question using the NVIDIA nemotron-4-340b-instruct model, 
        based on Relevance, Accuracy, Faithfulness, and Coherence using a Likert scale.

        Args:
            question (str): The original question.
            answer (str): The generated answer that needs to be rated.
            context (str): The document context retrieved for the question.

        Returns:
            Dict[str, int]: A dictionary containing the ratings for Relevance, Accuracy, Faithfulness, and Coherence.
        """
        prompt = f"""
        Question: {question}
        Answer: {answer}
        Context: {context}

        Please rate the quality of the answer based on the following criteria using a Likert scale from 1 (Strongly Disagree) to 5 (Strongly Agree):
        1. Relevance: How relevant is the answer to the question?
        2. Accuracy: How accurate is the answer in relation to the provided context?
        3. Faithfulness: How faithful is the answer to the information provided in the context?
        4. Coherence: How coherent and well-structured is the answer?

        IMPORTANT: Your response MUST strictly follow the format below. Any deviation from this format will be considered invalid. Do NOT include any additional information, explanations, or comments outside of the exact format specified:

        Relevance: [1-5]
        Accuracy: [1-5]
        Faithfulness: [1-5]
        Coherence: [1-5]

        Your response should only contain these four lines in the exact format above. No other text is permitted.
        """

            
        try:
            completion = nvidia_client.chat.completions.create(
                model="nvidia/nemotron-4-340b-instruct",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.2,
                top_p=0.7,
                max_tokens=100
            )
            response_content = completion.choices[0].message.content

            ratings = {
                "Relevance": int(response_content.split("Relevance: ")[1].split("\n")[0]),
                "Accuracy": int(response_content.split("Accuracy: ")[1].split("\n")[0]),
                "Faithfulness": int(response_content.split("Faithfulness: ")[1].split("\n")[0]),
                "Coherence": int(response_content.split("Coherence: ")[1].split("\n")[0])
            }
        
        except (IndexError, ValueError) as e:
            logging.error(f"Error extracting ratings from NVIDIA LLM response: {e}")
            ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}
        
        except (ConnectionError, Timeout) as e:
            logging.error(f"Network-related error during NVIDIA LLM completion: {e}")
            ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}
        
        except RequestException as e:
            logging.error(f"Request error during NVIDIA LLM completion: {e}")
            ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}
        
        except Exception as e:
            logging.error(f"An unexpected error occurred during NVIDIA LLM completion: {e}")
            ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}

        # Example usage:
        result = evaluate_answer_with_context_in_prompt("nvidia/nemotron-4-340b-reward", question, context, answer)    
        rewardmodel_scores = result['scores']    

        return ratings, rewardmodel_scores

    def add_to_json(self, chunk: str, questions: List[str]):
        """Adds question-answer pairs and their ratings to the JSON data list.

        Args:
            chunk (str): The text chunk related to the questions and answers.
            questions (List[str]): List of questions generated from the chunk.
        """
        for question in questions:
            answer = self.generate_answer(question, chunk)
            ratings,  rewardmodel_scores = self.critique(question, answer, chunk)
            data_point = {
                "question": question,
                "context": chunk,
                "answer": answer,
                "ratings": ratings,
                "scores": rewardmodel_scores
            }
            self.data.append(data_point)

    def run(self):
        """Runs the entire pipeline to generate the dataset and save it to a JSON file."""
        pdf_files = [os.path.join(self.directory_path, f) for f in os.listdir(self.directory_path) if f.endswith('.pdf')]
        
        for file_path in pdf_files:
            logger.info(f"Processing file: {file_path}")
            chunks = self.get_chunks(file_path, self.chunk_size)
            logger.info(f"Number of chunks created: {len(chunks)}")

            for chunk in chunks:
                questions = self.generate_questions(chunk)
                self.add_to_json(chunk, questions)

        # Save the generated data to a JSON file
        try:
            with open(self.output_file, 'w') as json_file:
                json.dump(self.data, json_file, indent=4)
            logger.info(f"Data saved to {self.output_file}")
        except IOError as e:
            logger.error(f"Failed to write data to {self.output_file}: {e}")
            raise

from huggingface_hub import login
from datasets import Dataset

def push_dataset_to_hub(file_path: str, token: str, repo_name: str):
    """Pushes the dataset to Hugging Face Hub.

    Args:
        file_path (str): Path to the JSON file containing the dataset.
        token (str): Hugging Face Hub authentication token.
        repo_name (str): The name of the repository to which the dataset will be pushed.
    """
    try:
        # Load data from JSON file (entire content is a JSON array)
        with open(file_path, 'r') as f:
            data = json.load(f)

        # Create a dataset from the list
        dataset = Dataset.from_list(data)

        # Log in to Hugging Face Hub
        login(token=token)

        # Push the dataset to Hugging Face Hub
        dataset.push_to_hub(repo_name)
        logger.info(f"Dataset successfully pushed to {repo_name}")
    
    except json.JSONDecodeError as e:
        logger.error(f"Failed to decode JSON file: {e}")
        raise
    except IOError as e:
        logger.error(f"Failed to read file {file_path}: {e}")
        raise
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
        raise

# Example usage
directory_path = "data"
output_file = "LocalRAFT.json"
simplified_raft = SimplifiedRAFTDataset(directory_path, output_file)
simplified_raft.run()

file_path = "LocalRAFT.json"
token = ""
repo_name = ""
push_dataset_to_hub(file_path, token, repo_name)





