import openai
import anthropic
import json
import logging
import sys
import re

# Set up logging to print logs to stdout and ensure visibility
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

# Define an error handler decorator to handle exceptions and log errors
def error_handler(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except openai.RateLimitError as e:
            logging.error(f"Rate limit exceeded in {func.__name__}: {str(e)}. Please try again later.")
            return None
        except openai.Timeout as e:
            logging.error(f"Timeout occurred in {func.__name__}: {str(e)}. The request took too long to complete.")
            return None
        except openai.APIError as e:
            logging.error(f"API error occurred in {func.__name__}: {str(e)}. Please check the API call.")
            return None
        except openai.OpenAIError as e:
            logging.error(f"OpenAI error occurred in {func.__name__}: {str(e)}. Please check your request and API settings.")
            return None
        except FileNotFoundError as e:
            logging.error(f"File not found: {str(e)}. Please check the file path.")
            return None
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error: {str(e)}. Please check the file format.")
            return None
        except Exception as e:
            logging.error(f"Unexpected error occurred in {func.__name__}: {str(e)}")
            return None
    return wrapper

@error_handler
def chemical_synthesis_pipeline_from_json(gpt4_client, claude_client, nvidia_client, json_file_path, num_questions, threshold=3.0):
    try:
        with open(json_file_path, 'r') as f:
            synthesis_pipeline = json.load(f)
    except FileNotFoundError:
        logging.error(f"The file {json_file_path} could not be found.")
        return None

    chemical_name = synthesis_pipeline.get("chemical_name", "")
    synthesis_description = synthesis_pipeline.get("synthesis_description", "")
    process_flow_diagram = synthesis_pipeline.get("process_flow_diagram", "")
    pid_suggestions = synthesis_pipeline.get("pid_suggestions", "")

    synthesis_description = synthesis_description.replace("\\n", "\n").replace("\\", "")
    process_flow_diagram = process_flow_diagram.replace("\\n", "\n").replace("\\", "")
    pid_suggestions = pid_suggestions.replace("\\n", "\n").replace("\\", "")

    QUESTION_PROMPT_TEMPLATE = f"""\
    You are to generate exactly {num_questions} questions based on the provided synthesis description, Process Flow Diagram (PFD), and Piping and Instrumentation Diagram (P&ID). **The questions must strictly focus on the following categories: Conceptual Understanding, Interpretation, Design and Engineering, and Analytical Thinking.**

    **Rules (to be strictly followed):**
    - Do not include any introductions, explanations, or summaries. **Only output questions.**
    - Do not use any phrases such as "Here are the questions" or "Based on the diagrams."
    - Do not include any numbers, bullet points, or any other symbols.
    - Each question must end with a question mark and be followed by a single newline character (\n).
    - If any text other than the questions is generated, it is **invalid output.**

    Synthesis Description: {{synthesis_description}}

    Process Flow Diagram: {{pfd_description}}

    Piping and Instrumentation Diagram: {{pid_description}}
    """
    
    def extract_questions_only(generated_text):
        # Regular expression to extract lines that end with a question mark
        questions = re.findall(r'.*\?$', generated_text, re.MULTILINE)
        # Join the questions with two newlines
        return "\n\n".join(questions)

    @error_handler
    def generate_questions_gpt4(client, synthesis_description, pfd_description, pid_description):
        prompt = QUESTION_PROMPT_TEMPLATE.format(
            synthesis_description=synthesis_description,
            pfd_description=pfd_description,
            pid_description=pid_description
        )
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with thoughtful and logical questions focusing on the PFD and P&ID."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def generate_questions_claude(client, synthesis_description, pfd_description, pid_description):
        prompt = QUESTION_PROMPT_TEMPLATE.format(
            synthesis_description=synthesis_description,
            pfd_description=pfd_description,
            pid_description=pid_description
        )
        message = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=4096,
            temperature=0.2,
            system="You are an expert in chemical engineering. Respond with thoughtful and logical questions focusing on the PFD and P&ID.",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return message.content[0].text
    
    questions_gpt4 = generate_questions_gpt4(gpt4_client, synthesis_description, process_flow_diagram, pid_suggestions)
    questions_claude = generate_questions_claude(claude_client, synthesis_description, process_flow_diagram, pid_suggestions)
    questions_claude = extract_questions_only(questions_claude)

    ANSWER_PROMPT_TEMPLATE = """\
    Provide clear, accurate, and concise answers to the following questions. Adhere strictly to the following rules to ensure very high scores in the following categories: 

    1. **Helpfulness:** Ensure each answer is extremely helpful, fully addressing the question in a way that resolves the query effectively.
    2. **Correctness:** Every answer must be factually correct, accurately referencing relevant details from the synthesis description, Process Flow Diagram (PFD), and Piping and Instrumentation Diagram (P&ID).
    3. **Coherence:** Ensure that each answer is logically structured and flows smoothly, making it easy for the reader to follow.
    4. **Complexity:** Balance complexity appropriately; provide necessary depth without making the answer overly complicated. Ensure the response is insightful where needed.
    5. **Verbosity:** Be concise but thorough. Include all essential details without adding unnecessary information. Ensure that the length of the answer aligns perfectly with the complexity of the question.

    Failure to adhere to these rules will lead to lower scores and suboptimal performance.

    Synthesis Description: {synthesis_description}

    Process Flow Diagram: {pfd_description}

    Piping and Instrumentation Diagram: {pid_description}

    Questions:
    {questions}
    """

    @error_handler
    def generate_answers_gpt4(client, synthesis_description, pfd_description, pid_description, question):
        prompt = ANSWER_PROMPT_TEMPLATE.format(
            synthesis_description=synthesis_description,
            pfd_description=pfd_description,
            pid_description=pid_description,
            questions=question
        )
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with thoughtful and logical answers focusing on the PFD and P&ID."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def generate_answers_claude(client, synthesis_description, pfd_description, pid_description, question):
        prompt = ANSWER_PROMPT_TEMPLATE.format(
            synthesis_description=synthesis_description,
            pfd_description=pfd_description,
            pid_description=pid_description,
            questions=question
        )
        message = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=4096,
            temperature=0.2,
            system="You are an expert in chemical engineering. Respond with well-reasoned and comprehensive answers focused on the PFD and P&ID.",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return message.content[0].text

    @error_handler
    def evaluate_content(client, model, content, prompt):
        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": content},
        ]
        response = client.chat.completions.create(model=model, messages=messages)
        scores = response.choices[0].logprobs.content
        return {"response": content, "scores": scores}

    qa_prompt= """\ 
                Evaluate the quality of the provided answer to the question based on the following criteria: Helpfulness, Correctness, Coherence, Complexity, Verbosity.
               """

    def process_qa_pairs(questions, generate_answers_func, evaluate_content_func, client, synthesis_description, pfd_description, pid_description, qa_prompt):
        filtered_qa_pairs = []
        for question in questions.split('\n\n'):  # Assuming each question is separated by a newline
            answer = generate_answers_func(client, synthesis_description, pfd_description, pid_description, question)
            qa_content_score = evaluate_content_func(nvidia_client, "nvidia/nemotron-4-340b-reward", answer, qa_prompt)

            scores = qa_content_score["scores"]
            
            # Extract the logprob scores
            score_dict = {
                "helpfulness": get_logprob(scores, "helpfulness"),
                "correctness": get_logprob(scores, "correctness"),
                "coherence": get_logprob(scores, "coherence"),
                "complexity": get_logprob(scores, "complexity"),
                "verbosity": get_logprob(scores, "verbosity"),
            }
            # Filter based on the threshold
            if score_dict["helpfulness"] >= threshold:
                filtered_qa_pairs.append({"question": question, "answer": answer, "scores": score_dict})

        return filtered_qa_pairs

    # Process QA pairs for GPT-4 and Claude
    filtered_qa_gpt4 = process_qa_pairs(questions_gpt4, generate_answers_gpt4, evaluate_content, gpt4_client, synthesis_description, process_flow_diagram, pid_suggestions, qa_prompt)
    filtered_qa_claude = process_qa_pairs(questions_claude, generate_answers_claude, evaluate_content, claude_client, synthesis_description, process_flow_diagram, pid_suggestions, qa_prompt)

    # Save the Filtered Data and Scores in the JSON file for each filtered QA pair
    if filtered_qa_gpt4:
        synthesis_pipeline["questions_answers_gpt4"] = filtered_qa_gpt4

    if filtered_qa_claude:
        synthesis_pipeline["questions_answers_claude"] = filtered_qa_claude

    with open(json_file_path, 'w') as f:
        json.dump(synthesis_pipeline, f, indent=4)

    logging.info(f"Synthesis pipeline for {chemical_name} updated and saved successfully.")

@error_handler
def get_logprob(scores, token_name):
    return next((score.logprob for score in scores if score.token == token_name), 0)

# Example usage
openai_client = openai.OpenAI(api_key="")
anthropic_client = anthropic.Anthropic(api_key="")
nvidia_client = openai.OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key="")

# File path to the existing JSON file
json_file_path = 'Aspirin_synthesis_pipeline_filtered-2.0.json'

# User-defined number of questions
num_questions = 1000

# Run the pipeline
chemical_synthesis_pipeline_from_json(
    gpt4_client=openai_client,
    claude_client=anthropic_client,
    nvidia_client=nvidia_client,
    json_file_path=json_file_path,
    num_questions=num_questions,
    threshold=1.0
)

