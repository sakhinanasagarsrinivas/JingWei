

import json

def process_synthesis_pipeline(drug_name):
    # Construct the JSON file path
    file_path = f'{drug_name}_synthesis_pipeline_filtered-2.0.json'

    try:
        # Load the JSON file
        with open(file_path, 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        print(f"The file for {drug_name} could not be found.")
        return
    except json.JSONDecodeError:
        print(f"Error decoding JSON from the file {file_path}.")
        return

    # Prepare the output in a human-readable format
    output = f"Chemical Name: {data.get('chemical_name', 'Unknown Chemical')}\n\n"

    output += "Synthesis Description:\n"
    output += data.get('synthesis_description', 'No synthesis description available.').replace("\\n", "\n").replace("\\", "") + "\n\n"

    output += "Process Flow Diagram:\n"
    output += data.get('process_flow_diagram', 'No process flow diagram available.').replace("\\n", "\n").replace("\\", "") + "\n\n"

    output += "Piping and Instrumentation Diagram (P&ID) Suggestions:\n"
    output += data.get('pid_suggestions', 'No P&ID suggestions available.').replace("\\n", "\n").replace("\\", "") + "\n\n"

    output += "Questions and Answers from GPT-4:\n"
    output += data.get('questions_answers_gpt4', 'No Q&A from GPT-4 available.').replace("\\n", "\n").replace("\\", "") + "\n\n"

    output += "Questions and Answers from Claude:\n"
    output += data.get('questions_answers_claude', 'No Q&A from Claude available.').replace("\\n", "\n").replace("\\", "") + "\n"

    # Write the output to a text file
    output_file_path = f'{drug_name}_Synthesis_Process.txt'

    try:
        with open(output_file_path, 'w') as output_file:
            output_file.write(output)
        print(f"The data has been written to {output_file_path}")
    except IOError:
        print(f"An error occurred while writing to {output_file_path}.")

# Example usage
process_synthesis_pipeline("Aspirin")

