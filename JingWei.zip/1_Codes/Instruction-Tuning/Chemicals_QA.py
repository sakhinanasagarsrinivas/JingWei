

import openai
import anthropic
import json
import logging
import sys

# Set up logging to print logs to stdout and ensure visibility
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))


# Define an error handler decorator to handle exceptions and log errors
def error_handler(func):
    """
    A decorator to wrap functions with error handling. Catches and logs specific errors related to API rate limits, 
    timeouts, general API issues, file handling, and network-related errors. If an error occurs, the function 
    returns None and logs the error.

    Args:
        func (function): The function to be wrapped with error handling.

    Returns:
        function: The wrapped function with error handling.
    """
    def wrapper(*args, **kwargs):
        try:
            # Attempt to run the wrapped function
            return func(*args, **kwargs)
        except openai.RateLimitError as e:
            logging.error(f"Rate limit exceeded in {func.__name__}: {str(e)}. Please try again later.")
            return None
        except openai.Timeout as e:
            logging.error(f"Timeout occurred in {func.__name__}: {str(e)}. The request took too long to complete.")
            return None
        except openai.APIError as e:
            logging.error(f"API error occurred in {func.__name__}: {str(e)}. Please check the API call.")
            return None
        except openai.OpenAIError as e:
            logging.error(f"OpenAI error occurred in {func.__name__}: {str(e)}. Please check your request and API settings.")
            return None
        except FileNotFoundError as e:
            logging.error(f"File not found: {str(e)}. Please check the file path.")
            return None
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error: {str(e)}. Please check the file format.")
            return None
        except Exception as e:
            logging.error(f"Unexpected error occurred in {func.__name__}: {str(e)}")
            return None  # Return None if an exception occurs
    return wrapper


@error_handler
def chemical_synthesis_pipeline(gpt4_client, claude_client, nvidia_client, chemical_name, threshold=3.0):
    """
    This function executes a multi-step chemical synthesis pipeline, including the generation of industrial synthesis
    descriptions, process flow diagrams (PFD), and piping and instrumentation diagrams (P&ID) for a given chemical.
    The function aggregates outputs from multiple large language models and filters them based on a threshold.

    Args:
        gpt4_client: The client object for interacting with the GPT-4 model.
        claude_client: The client object for interacting with the Claude model.
        nvidia_client: The client object for interacting with the Nvidia model.
        chemical_name (str): The name of the chemical for which the pipeline is being executed.
        threshold (float): The score threshold for filtering the results.

    Returns:
        None. The results are saved in a JSON file named after the chemical.
    """
    
    SYNTHESIS_PROMPT_TEMPLATE = """\
    Provide a comprehensive and detailed description of the industrial synthesis process for {chemical_name}. Your description should include:
    - All key chemical reactions, including reactants, intermediates, and products.
    - The types of reactors used (e.g., CSTR, PFR) and their operating conditions (e.g., temperature, pressure).
    - Details of any purification steps, such as distillation, crystallization, or filtration, including the equipment used.
    - Handling and treatment of by-products and waste streams.
    - Any recycling loops and the integration of heat exchange systems to optimize energy use.
    - Specific safety measures taken during the synthesis, especially when dealing with hazardous chemicals.
    The description should be suitable for an engineer looking to understand the process in detail for implementation in a large-scale industrial setting.
    """

    @error_handler
    def generate_synthesis_description_gpt4(client, chemical_name):
        """
        Generates a detailed synthesis description using the GPT-4 model.

        Args:
            client: The GPT-4 client object.
            chemical_name (str): The name of the chemical for which the synthesis description is being generated.

        Returns:
            str: The generated synthesis description.
        """
        prompt = SYNTHESIS_PROMPT_TEMPLATE.format(chemical_name=chemical_name)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with detailed, technical information."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def generate_synthesis_description_claude(client, chemical_name):
        """
        Generates a detailed synthesis description using the Claude model.

        Args:
            client: The Claude client object.
            chemical_name (str): The name of the chemical for which the synthesis description is being generated.

        Returns:
            str: The generated synthesis description.
        """
        prompt = SYNTHESIS_PROMPT_TEMPLATE.format(chemical_name=chemical_name)
        message = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=4096,
            temperature=0.2,
            system="You are an expert in chemical engineering. Respond with detailed, technical information.",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return message.content[0].text

    # Generate descriptions from both proposers
    synthesis_description_omni = generate_synthesis_description_gpt4(gpt4_client, chemical_name)
    synthesis_description_haiku = generate_synthesis_description_claude(claude_client, chemical_name)

    @error_handler
    def aggregate_descriptions(client, description_1, description_2, step):
        """
        Aggregates two descriptions into a comprehensive output based on the specified step.

        Args:
            client: The GPT-4 client object.
            description_1 (str): The first description to be aggregated.
            description_2 (str): The second description to be aggregated.
            step (str): The current step of the pipeline (e.g., "synthesis", "PFD", "PID").

        Returns:
            str: The aggregated description.
        """
        if step == "synthesis":
            AGGREGATION_PROMPT_TEMPLATE = """\
            You are an expert in industrial chemical processes. Your task is to combine the following two synthesis descriptions into a comprehensive, clear, and detailed process overview. Focus on:
            1. Ensuring the completeness of chemical reactions, including the accuracy of reactants, intermediates, and products.
            2. Clarifying the types and conditions of reactors used, ensuring no critical details are missed.
            3. Enhancing the description of purification steps and handling of by-products, including any safety measures and environmental considerations.
            4. Optimizing the process for industrial scalability, including recycling loops and energy integration.
            Description 1: {description_1}
            Description 2: {description_2}
            Produce a synthesis description that is ready for use in a large-scale industrial setting.
            """

        elif step == "PFD":
            AGGREGATION_PROMPT_TEMPLATE = """\
            You are a process design expert. Your task is to combine the following two process flow diagram (PFD) descriptions into a single, optimized process flow. Focus on:
            1. Ensuring all major equipment is accurately described and properly integrated into the process flow.
            2. Enhancing the clarity of material flows, including recycling streams, and ensuring that all phases and phase transitions are clearly represented.
            3. Identifying and suggesting improvements for any potential bottlenecks in the process flow.
            4. Ensuring the process flow is optimized for energy efficiency through heat integration and other means.
            Description 1: {description_1}
            Description 2: {description_2}
            Produce a process flow diagram description that is clear, detailed, and optimized for large-scale industrial production.
            """

        elif step == "PID":
            AGGREGATION_PROMPT_TEMPLATE = """\
            You are an expert in Piping and Instrumentation Diagrams (P&ID). Your task is to combine the following two P&ID suggestions into a coherent, detailed, and optimized set of recommendations. Focus on:
            1. Ensuring that all critical sensors and control elements are accurately placed for optimal process monitoring and control.
            2. Enhancing the description of control loops and safety instrumentation to ensure compliance with industry standards and regulations.
            3. Addressing redundancy and reliability in the placement of instrumentation to minimize downtime and ensure continuous operation.
            4. Providing recommendations for piping materials and control systems integration that ensure both safety and efficiency.
            Description 1: {description_1}
            Description 2: {description_2}
            Produce a P&ID that is optimized for safety, reliability, and efficiency in a large-scale industrial setting.
            """

        prompt = AGGREGATION_PROMPT_TEMPLATE.format(description_1=description_1, description_2=description_2)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    # Aggregate descriptions
    synthesis_description = aggregate_descriptions(gpt4_client, synthesis_description_omni, synthesis_description_haiku, "synthesis")

    # Process Flow Diagram Generation (Textual)
    PROCESS_FLOW_PROMPT_TEMPLATE = """\
    Based on the following synthesis description, create a detailed textual Process Flow Diagram (PFD) for the synthesis of {chemical_name}. Your PFD should include:
    - Major equipment involved at each step, such as reactors, heat exchangers, distillation columns, separators, pumps, and compressors.
    - The flow of raw materials, intermediates, and products through the process, including any recycling streams.
    - Details of heat integration, such as the use of heat exchangers to recover energy from exothermic reactions or to preheat reactants.
    - A clear representation of phases (e.g., gas, liquid, solid) in each unit operation, highlighting phase transitions where applicable.
    - Specific operating conditions at key stages, including temperatures, pressures, and flow rates, to ensure proper operation.
    - The identification of potential bottlenecks in the process flow, and suggestions for optimizing throughput.
    Ensure that the PFD is designed according to industry standards and is suitable for scaling up to large-scale production.
    Synthesis Description: {synthesis_description}
    """

    @error_handler
    def generate_process_flow_diagram_gpt4(client, chemical_name, synthesis_description):
        """
        Generates a detailed process flow diagram (PFD) using the GPT-4 model.

        Args:
            client: The GPT-4 client object.
            chemical_name (str): The name of the chemical for which the PFD is being generated.
            synthesis_description (str): The synthesis description to be used as a basis for the PFD.

        Returns:
            str: The generated process flow diagram.
        """
        prompt = PROCESS_FLOW_PROMPT_TEMPLATE.format(chemical_name=chemical_name, synthesis_description=synthesis_description)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with detailed, technical information."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def generate_process_flow_diagram_claude(client, chemical_name, synthesis_description):
        """
        Generates a detailed process flow diagram (PFD) using the Claude model.

        Args:
            client: The Claude client object.
            chemical_name (str): The name of the chemical for which the PFD is being generated.
            synthesis_description (str): The synthesis description to be used as a basis for the PFD.

        Returns:
            str: The generated process flow diagram.
        """
        prompt = PROCESS_FLOW_PROMPT_TEMPLATE.format(chemical_name=chemical_name, synthesis_description=synthesis_description)
        message = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=4096,
            temperature=0.2,
            system="You are an expert in chemical engineering. Respond with detailed, technical information.",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return message.content[0].text

    # Generate PFDs from both proposers
    process_flow_diagram_omni = generate_process_flow_diagram_gpt4(gpt4_client, chemical_name, synthesis_description)
    process_flow_diagram_haiku = generate_process_flow_diagram_claude(claude_client, chemical_name, synthesis_description)

    # Aggregate PFDs
    process_flow_diagram = aggregate_descriptions(gpt4_client, process_flow_diagram_omni, process_flow_diagram_haiku, "PFD")

    # Piping and Instrumentation Diagram (P&ID) Suggestions
    PID_PROMPT_TEMPLATE = """\
    Create a detailed Piping and Instrumentation Diagram (P&ID) based on the following process flow diagram (PFD) for the synthesis of {chemical_name}. The P&ID should include:
    - Detailed placement of sensors (e.g., temperature, pressure, flow, and level sensors) at critical points in the process to ensure precise monitoring.
    - Specification of control valves, actuators, and control loops required to maintain process parameters within the desired range, including examples of typical control strategies (e.g., feedback, feedforward, cascade control).
    - Identification of safety instrumentation, such as pressure relief valves, emergency shutdown systems, interlocks, and alarms, to prevent accidents and ensure compliance with safety regulations.
    - Details of the instrumentation needed for process optimization, such as advanced process control (APC) systems, model predictive control (MPC), and real-time data analytics.
    - Consideration of redundancy and reliability in the placement of key sensors and control elements to ensure continuous operation and minimize downtime.
    - Recommendations for the types of piping materials to be used, considering the chemical compatibility, temperature, and pressure of the process streams.
    - Suggestions for the integration of control systems with a distributed control system (DCS) or supervisory control and data acquisition (SCADA) system for centralized monitoring and control.
    Your P&ID suggestions should align with industry best practices and standards (e.g., ANSI/ISA-5.1) and be suitable for large-scale industrial production.
    Process Flow Diagram (PFD): {process_flow_diagram}
    """

    @error_handler
    def generate_pid_suggestions_gpt4(client, chemical_name, process_flow_diagram):
        """
        Generates detailed Piping and Instrumentation Diagram (P&ID) suggestions using the GPT-4 model.

        Args:
            client: The GPT-4 client object.
            chemical_name (str): The name of the chemical for which the P&ID suggestions are being generated.
            process_flow_diagram (str): The process flow diagram to be used as a basis for the P&ID suggestions.

        Returns:
            str: The generated P&ID suggestions.
        """
        prompt = PID_PROMPT_TEMPLATE.format(chemical_name=chemical_name, process_flow_diagram=process_flow_diagram)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with detailed, technical information."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def generate_pid_suggestions_claude(client, chemical_name, process_flow_diagram):
        """
        Generates detailed Piping and Instrumentation Diagram (P&ID) suggestions using the Claude model.

        Args:
            client: The Claude client object.
            chemical_name (str): The name of the chemical for which the P&ID suggestions are being generated.
            process_flow_diagram (str): The process flow diagram to be used as a basis for the P&ID suggestions.

        Returns:
            str: The generated P&ID suggestions.
        """
        prompt = PID_PROMPT_TEMPLATE.format(chemical_name=chemical_name, process_flow_diagram=process_flow_diagram)
        message = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=4096,
            temperature=0.2,
            system="You are an expert in chemical engineering. Respond with detailed, technical information.",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )
        return message.content[0].text

    # Generate P&ID suggestions from both proposers
    pid_suggestions_omni = generate_pid_suggestions_gpt4(gpt4_client, chemical_name, process_flow_diagram)
    pid_suggestions_haiku = generate_pid_suggestions_claude(claude_client, chemical_name, process_flow_diagram)

    # Aggregate P&ID suggestions
    pid_suggestions = aggregate_descriptions(gpt4_client, pid_suggestions_omni, pid_suggestions_haiku, "PID")

    @error_handler
    def get_scores_from_response(openai_response_template):
        """
        Extracts the logprobs (scores) from the OpenAI API response template.

        Args:
            openai_response_template: The OpenAI API response object containing logprobs.

        Returns:
            dict: A dictionary containing token logprobs.
        """
        logprobs = openai_response_template.choices[0].logprobs.content
        score_dict = {score.token: score.logprob for score in logprobs}
        return score_dict

    @error_handler
    def get_response_and_scores(client, model, question, response_content):
        """
        Sends a question to the API, receives the response, and calculates the scores for the response.

        Args:
            client: The Nvidia client object.
            model (str): The model name to be used for scoring.
            question (str): The question or prompt being evaluated.
            response_content (str): The response content to be scored.

        Returns:
            dict: A dictionary containing the response and its corresponding scores.
        """
        messages = [
            {"role": "user", "content": question},
            {"role": "assistant", "content": response_content},
        ]
        response = client.chat.completions.create(model=model, messages=messages)
        scores = get_scores_from_response(response)
        return {"response": response_content, "scores": scores}

    @error_handler
    def process_content_with_scores(nvidia_client, model, content_list, prompt_list):
        """
        Processes a list of content and generates scores for each based on the given prompts.

        Args:
            nvidia_client: The Nvidia client object.
            model (str): The model name to be used for scoring.
            content_list (list): A list of content to be scored.
            prompt_list (list): A list of prompts corresponding to the content to be scored.

        Returns:
            list: A list of dictionaries containing the content and their corresponding scores.
        """
        content_score_list = []
        for content, prompt in zip(content_list, prompt_list):
            result = get_response_and_scores(nvidia_client, model, prompt, content)
            content_score_list.append(result)
        return content_score_list

    # Create prompts for scoring each section
    synthesis_prompt = f"Evaluate the industrial synthesis description for {chemical_name}."
    pfd_prompt = f"Evaluate the process flow diagram for synthesizing {chemical_name}."
    pid_prompt = f"Evaluate the P&ID suggestions for {chemical_name}."

    content_list = [synthesis_description, process_flow_diagram, pid_suggestions]
    prompt_list = [synthesis_prompt, pfd_prompt, pid_prompt]

    content_score_list = process_content_with_scores(nvidia_client, "nvidia/nemotron-4-340b-reward", content_list, prompt_list)
   
    # Filter based on threshold
    filtered_content = [
        content for content, score in zip(content_list, content_score_list)
        if score["scores"].get("helpfulness", 0) >= threshold
    ]

    # Save the filtered data along with scores
    synthesis_pipeline = {
        "chemical_name": chemical_name,
        "synthesis_description": filtered_content[0].strip() if filtered_content else "Filtered Out",
        "process_flow_diagram": filtered_content[1].strip() if len(filtered_content) > 1 else "Filtered Out",
        "pid_suggestions": filtered_content[2].strip() if len(filtered_content) > 2 else "Filtered Out",
        "scores": {
            "synthesis_description_scores": content_score_list[0]["scores"] if len(content_score_list) > 0 else {},
            "process_flow_diagram_scores": content_score_list[1]["scores"] if len(content_score_list) > 1 else {},
            "pid_suggestions_scores": content_score_list[2]["scores"] if len(content_score_list) > 2 else {},
        }
    }

    with open(f'{chemical_name}_synthesis_pipeline_filtered-{threshold}.json', 'w') as f:
        json.dump(synthesis_pipeline, f, indent=4)

    print(f"Synthesis pipeline for {chemical_name} generated successfully.")

# Example usage
gpt4_client = openai.OpenAI(api_key="")
claude_client = anthropic.Anthropic(api_key="")
nvidia_client = openai.OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key="")

chemical_synthesis_pipeline(gpt4_client, claude_client, nvidia_client, chemical_name="Aspirin", threshold=2.0)
