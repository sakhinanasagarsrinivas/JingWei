

# Installs Unsloth, Xformers (Flash Attention) and all other packages!
# pip install "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git"
# pip install --no-deps "xformers<0.0.27" "trl<0.9.0" peft accelerate bitsandbytes
# pip install transformers[torch] bitsandbytes


import os
import torch
from unsloth import FastLanguageModel
from datasets import load_dataset
from trl import SFTTrainer
from transformers import TrainingArguments
from unsloth import is_bfloat16_supported
from unsloth import PatchDPOTrainer
from trl import DPOTrainer
from huggingface_hub import login

# Set environment variables
os.environ["WANDB_DISABLED"] = "true"

def fine_tune_unsloth_model(dataset_dir):
    """
    Fine-tunes the Unsloth language model using the provided dataset.

    Args:
        dataset_dir (str): The directory containing the dataset for fine-tuning.

    Returns:
        tuple: A tuple containing the fine-tuned model, tokenizer, and training statistics.
    """
    try:
        # Configuration settings
        max_seq_length = 4096  # Choose any! We auto support RoPE Scaling internally!
        dtype = None  # None for auto detection. Float16 for Tesla T4, V100, Bfloat16 for Ampere+
        load_in_4bit = True  # Use 4bit quantization to reduce memory usage. Can be False.

        # Load the model and tokenizer
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name="unsloth/gemma-2b",
            max_seq_length=max_seq_length,
            dtype=dtype,
            load_in_4bit=load_in_4bit,
        )

        def formatting_prompts_func(examples):
            """
            Formats prompts for fine-tuning by applying a DPO prompt template.

            Args:
                examples (dict): A dictionary containing prompt examples with keys 'prompt', 'chosen', and 'rejected'.

            Returns:
                dict: A dictionary with formatted text data.
            """
            dpo_prompt_template = """You will be provided with a question and two responses. Your task is to generate a response that aligns with the qualities of the better response, while avoiding the shortcomings of the weaker response.

            ### Question:
            {}

            ### Better Response (Preferred):
            {}

            ### Weaker Response (Not Preferred):
            {}
            """
            EOS_TOKEN = tokenizer.eos_token  # Ensure you add EOS_TOKEN to mark the end of the text
            prompts = examples["prompt"]
            chosens = examples["chosen"]
            rejecteds = examples["rejected"]
            texts = []
            for prompt, chosen, rejected in zip(prompts, chosens, rejecteds):
                text = dpo_prompt_template.format(prompt, chosen, rejected) + EOS_TOKEN
                texts.append(text)
            return {"text": texts}

        # Load and preprocess the dataset
        dataset = load_dataset(dataset_dir, split="train")
        dataset = dataset.map(formatting_prompts_func, batched=True)

        # Do model patching and add fast LoRA weights
        model = FastLanguageModel.get_peft_model(
            model,
            r=16,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                            "gate_proj", "up_proj", "down_proj",],
            lora_alpha=16,
            lora_dropout=0,  # Supports any, but = 0 is optimized
            bias="none",    # Supports any, but = "none" is optimized
            use_gradient_checkpointing="unsloth",  # True or "unsloth" for very long context
            random_state=3407,
            max_seq_length=max_seq_length,
        )

        # Initialize the trainer
        dpo_trainer = DPOTrainer(
            model=model,
            ref_model=None,
            args=TrainingArguments(
                per_device_train_batch_size=2,
                gradient_accumulation_steps=4,
                warmup_ratio=0.1,
                num_train_epochs=1,
                fp16=not is_bfloat16_supported(),
                bf16=is_bfloat16_supported(),
                logging_steps=1,
                optim="adamw_8bit",
                seed=42,
                output_dir="outputs",
            ),
            beta=0.1,
            train_dataset=dataset,
            tokenizer=tokenizer,
            max_length=4096,
            max_prompt_length=2048,
        )

        # Train the model
        trainer_stats = dpo_trainer.train()

        # Return the model, tokenizer, and training statistics
        return model, tokenizer, trainer_stats

    except FileNotFoundError as e:
        print(f"Error: The dataset directory was not found. {e}")
    except torch.cuda.CudaError as e:
        print(f"Error: CUDA-related issue encountered. {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Example usage
dataset_dir = "SagarSrinivas/dpo_dataset"
model, tokenizer, trainer_stats = fine_tune_unsloth_model(dataset_dir)

def save_model_and_tokenizer(model, tokenizer, directory):
    """
    Saves the fine-tuned model and tokenizer to the specified directory.

    Args:
        model (PreTrainedModel): The fine-tuned model to be saved.
        tokenizer (PreTrainedTokenizer): The tokenizer to be saved.
        directory (str): The directory to save the model and tokenizer.
    """
    try:
        model.save_pretrained(directory)  # Local saving
        tokenizer.save_pretrained(directory)
    except Exception as e:
        print(f"Error occurred while saving the model and tokenizer: {e}")

def push_model_to_hub(model, tokenizer, model_name):
    """
    Pushes the model and tokenizer to the Hugging Face Hub.

    Args:
        model (PreTrainedModel): The fine-tuned model to be pushed.
        tokenizer (PreTrainedTokenizer): The tokenizer to be pushed.
        model_name (str): The name under which the model will be pushed to the Hub.
    """
    try:
        login(token="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")  # Replace with your token
        model.push_to_hub(model_name)
        tokenizer.push_to_hub(model_name)
    except Exception as e:
        print(f"Error occurred while pushing the model to the Hub: {e}")

# Save model and tokenizer locally
save_model_and_tokenizer(model, tokenizer, "lora_model")

# Push the model and tokenizer to Hugging Face Hub
push_model_to_hub(model, tokenizer, "SagarSrinivas/lora_model")


