# html_pipeline.py

import os
import requests
import pandas as pd
from bs4 import BeautifulSoup
from serpapi import GoogleSearch
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

def load_model():
    """
    Load the GPT-4o-mini model with predefined parameters.

    This function initializes and returns an instance of the GPT-4o-mini 
    language model using the ChatOpenAI library.

    Returns:
        ChatOpenAI: An instance of the GPT-4o-mini model with a fixed temperature of 0.
    """
    return ChatOpenAI(model="gpt-4o-mini", temperature=0)

def search_html(query, api_key):
    """
    Search for HTML links related to a query using the SerpAPI search engine.

    This function modifies the input query to exclude certain file types 
    (e.g., PDF, research papers, PowerPoint presentations) and retrieves 
    HTML links using the SerpAPI.

    Args:
        query (str): The search query provided by the user.
        api_key (str): The API key for authenticating with the SerpAPI service.

    Returns:
        list: A list containing up to one valid HTML link found in the search results. 
              If no links are found, returns an empty list.
    """
    # Modify query to exclude unwanted file types
    modified_query = f"{query} -pdf -research -article -slideshare -ppt"

    # Prepare search parameters for SerpAPI
    params = {
        "engine": "google",
        "q": modified_query,
        "api_key": api_key
    }

    # Perform search using SerpAPI
    search = GoogleSearch(params)
    results = search.get_dict()

    # Extract HTML links from search results
    html_links = []
    if "organic_results" in results:
        for result in results["organic_results"]:
            html_url = result.get("link")
            if html_url and html_url.startswith("http"):  # Validate link format
                html_links.append(html_url)
                print(f"Found HTML link: {html_url}")
            if len(html_links) >= 1:  # Limit results to 1 HTML link
                break
    else:
        print("No HTML results found.")

    return html_links

def scrape_html_and_extract_text(url):
    """
    Scrape HTML content from a URL and extract the visible text.

    This function sends an HTTP GET request to the specified URL, parses the 
    HTML response, and extracts the text content. The extraction logic can 
    be customized as needed based on the specific structure of the HTML.

    Args:
        url (str): The URL of the web page to scrape.

    Returns:
        str: The extracted text content from the web page, separated by newlines. 
             Returns `None` if the URL cannot be scraped or an error occurs.

    Exceptions:
        Handles any exceptions that occur during the request or parsing process 
        and prints an error message indicating the issue.
    """
    try:
        # Send an HTTP GET request to the specified URL
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for HTTP response codes >= 400
        
        # Parse the HTML content using BeautifulSoup
        soup = BeautifulSoup(response.content, 'html.parser')

        # Extract and return the visible text from the HTML
        text = soup.get_text(separator="\n", strip=True)
        return text
    except Exception as e:
        print(f"Could not scrape {url}. Reason: {e}")
        return None

def clean_text(text):
    """
    Clean and format the extracted text by removing unnecessary characters.

    This function replaces newline characters, carriage returns, and commas 
    in the input text to produce a cleaner and more consistent output.

    Args:
        text (str): The raw text extracted from an HTML page.

    Returns:
        str: The cleaned and formatted text with newline and carriage return 
             characters replaced by spaces, and commas removed.
    """
    return text.replace('\n', ' ').replace('\r', '').replace(',', ' ')


def main(query):
    """
    Main function for processing a query through the HTML pipeline.

    This function performs the following tasks:
    1. Searches for HTML links relevant to the given query using a Google API key.
    2. Scrapes and extracts text content from the HTML pages associated with the found links.
    3. Loads a GPT-4o model to generate detailed process descriptions, Process Flow Diagrams (PFDs),
       and Piping and Instrumentation Diagram (P&ID) suggestions for the given query.
    4. Summarizes the scraped text and model responses into a structured format.
    5. Saves the combined data, including the source URL, extracted text, and generated responses, into a CSV file.

    Args:
        query (str): The topic or keyword for which to generate industrial synthesis details.

    Steps in Detail:
    1. **Search for HTML Links**:
       - Uses the `search_html` function to find HTML links related to the query.
       - Requires an API key stored in the `SERP_API_KEY` environment variable.

    2. **Scrape and Extract Text**:
       - Iterates over the found HTML links.
       - Extracts readable text content using the `scrape_html_and_extract_text` function.

    3. **Generate Model Responses**:
       - Constructs a detailed prompt with instructions specific to the chemical engineering context of the query.
       - Includes elements like chemical reactions, reactor types, purification steps, by-product handling,
         recycling, heat integration, textual Process Flow Diagrams (PFDs), and Piping and Instrumentation Diagram (P&ID) suggestions.
       - The GPT-4o model is invoked to generate responses based on the extracted text.

    4. **Save Results**:
       - Combines the source URL, extracted text, and model responses into a list.
       - Saves the results in a CSV file located in the `agents_output` directory.

    Outputs:
        - A CSV file containing the source URL, extracted text, and GPT-4o-generated responses.

    Returns:
        None
    """
    # Retrieve the API key for searching HTML links
    API_KEY = os.getenv('SERP_API_KEY')  # Use your Google API key

    # Search for HTML links related to the query
    html_links = search_html(query, API_KEY)

    # Prepare a list to hold the extracted and summarized data
    combined_data = []

    # Load the GPT-4o model
    model = load_model()

    # Scrape and extract text from found HTML links
    for html_url in html_links:
        # Extract text content from the HTML page
        text = scrape_html_and_extract_text(html_url)
        if text:  # Only process if text extraction was successful
            # Construct the detailed prompt for the GPT-4o model
            prompt_text = f"""\ 
            You are a chemical engineer tasked with detailing the industrial synthesis process for {query}. Your description must be comprehensive and cater to the needs of engineers looking to implement the process in a large-scale industrial setting. Include the following elements:

            1. **Chemical Reactions**: Describe all key chemical reactions involved in the synthesis. Clearly outline the reactants, intermediates, and final products.

            2. **Reactor Types and Operating Conditions**: Identify the types of reactors utilized (e.g., Continuous Stirred Tank Reactor (CSTR), Plug Flow Reactor (PFR)). Specify the operating conditions for each reactor type, including temperature ranges, pressure levels, and any catalyst used.

            3. **Purification Steps**: Detail any purification methods applied to achieve the desired product purity. This may include techniques like distillation, crystallization, filtration, or extraction. Describe the equipment utilized in these steps and their operating conditions.

            4. **By-product Handling**: Discuss how by-products and waste streams will be managed. Describe treatment processes, storage, or disposal methods to mitigate environmental impact.

            5. **Recycling and Heat Integration**: Include any recycling loops in the process and detail how heat integration systems are utilized to optimize energy use, such as heat exchangers that recover energy from exothermic reactions.

            ---

            **Process Flow Diagram Generation (Textual)**

            Based on the synthesis description you’ve provided, create a detailed textual Process Flow Diagram (PFD) for the synthesis of {query}. Your PFD should include:

            - **Major Equipment**: List and describe all major equipment at each step, such as reactors, heat exchangers, distillation columns, separators, pumps, and compressors.

            - **Material Flow**: Illustrate the flow of raw materials, intermediates, and final products through the process, including any recycling streams.

            - **Heat Integration**: Provide details on how heat integration is incorporated, including the application of heat exchangers to recover energy.

            - **Phase Representation**: Clearly depict the phases of substances (gas, liquid, solid) in each unit operation, indicating any relevant phase transitions.

            - **Operating Conditions**: Specify the operating conditions at key stages, including temperatures, pressures, and flow rates.

            - **Bottleneck Identification**: Identify potential bottlenecks in the process flow and suggest methods for optimizing throughput.

            Ensure that the PFD adheres to industry standards and is suited for large-scale production.

            ---

            **Piping and Instrumentation Diagram (P&ID) Suggestions**

            Create a detailed Piping and Instrumentation Diagram (P&ID) based on the provided Process Flow Diagram (PFD) for the synthesis of {query}. Your P&ID should include:

            - **Sensor Placement**: Detail where sensors (temperature, pressure, flow, and level) should be located for monitoring critical process parameters.

            - **Control Valves and Strategies**: Specify the control valves, actuators, and control loops necessary to maintain process parameters—including examples of control strategies like feedback or cascade control.

            - **Safety Instrumentation**: Identify safety instrumentation such as pressure relief valves, emergency shutdown systems, interlocks, and alarms to ensure safety compliance.

            - **Instrumentation for Optimization**: Describe instrumentation needed for process optimization, including advanced process control (APC) systems and real-time data analytics.

            - **Redundancy**: Consider redundancy and reliability in the arrangement of key sensors and control elements to enhance continuous operation.

            - **Piping Material Recommendations**: Suggest appropriate piping materials considering the compatibility, temperature, and pressure of the process streams.

            - **Control System Integration**: Recommend integration with control systems like Distributed Control Systems (DCS) or SCADA systems for centralized monitoring and control.

            Your P&ID suggestions should conform to industry best practices and standards, making it suitable for large-scale production.

            \n\n{text}
            """
            message = HumanMessage(content=prompt_text)

            # Invoke the GPT-4o model with the constructed prompt
            response = model.invoke([message])
            gpt4_response = response.content

            # Append the URL, extracted text, and GPT-4o response to the data list
            combined_data.append({"URL": html_url, "Extracted Text": text, "Answer": gpt4_response})

    # Define the output directory for saving results
    output_directory = "agents_output"
    os.makedirs(output_directory, exist_ok=True)

    # Save combined data to a CSV if any data was processed
    if combined_data:
        df = pd.DataFrame(combined_data)
        csv_file_path = os.path.join(output_directory, "html_response.csv")
        df.to_csv(csv_file_path, index=False)
        print(f"Extracted and summarized texts saved to: {csv_file_path}")
    else:
        print("No texts to save.")



