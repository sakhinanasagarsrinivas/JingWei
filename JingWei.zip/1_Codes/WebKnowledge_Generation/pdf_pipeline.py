# pdf_pipeline.py

import os
import re
import uuid
import base64
import requests
import pandas as pd
from PIL import Image
import htmltabletomd
from io import BytesIO
from operator import itemgetter
from serpapi import GoogleSearch
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from IPython.display import HTML, display, Image
from langchain_core.messages import HumanMessage
from langchain_community.storage import RedisStore
from IPython.display import HTML, display, Markdown
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain.retrievers.multi_vector import MultiVectorRetriever
from langchain_community.utilities.redis import get_client
from langchain_community.document_loaders import UnstructuredPDFLoader
from langchain_core.runnables import RunnableLambda, RunnablePassthrough


# Initialize the ChatOpenAI model with specified parameters
chatgpt = ChatOpenAI(model_name='gpt-4o-mini', temperature=0)

# Initialize the OpenAI embeddings model for text embedding generation
openai_embed_model = OpenAIEmbeddings(model='text-embedding-3-small')

def search_pdfs(query, api_key):
    """
    Search for PDF links based on a given query using a search engine API.

    Args:
        query (str): The search query provided by the user.
        api_key (str): The API key required to authenticate the search engine request.

    Returns:
        list: A list of up to 5 PDF URLs retrieved from the search results.
    """
    # Append the 'filetype:pdf' filter to the query to restrict results to PDF files
    query_with_filetype = f"{query} filetype:pdf"  

    # Define parameters for the search engine API call
    params = {
        "engine": "google",  # Specify the search engine (Google in this case)
        "q": query_with_filetype,  # Include the modified query
        "api_key": api_key  # Authentication for the API
    }

    # Perform the search using the GoogleSearch wrapper with the specified parameters
    search = GoogleSearch(params)
    results = search.get_dict()  # Fetch the search results as a dictionary

    # Initialize an empty list to store found PDF links
    pdf_links = []

    # Check if the search results contain organic (non-sponsored) results
    if "organic_results" in results:
        # Iterate through the organic results
        for result in results["organic_results"]:
            # Extract the link to the result
            pdf_url = result.get("link")
            
            # Check if the link ends with '.pdf' to ensure it's a PDF file
            if pdf_url and pdf_url.endswith(".pdf"):
                pdf_links.append(pdf_url)  # Add the PDF URL to the list
                print(f"Found PDF link: {pdf_url}")  # Output the found link for debugging/verification
            
            # Stop after collecting a maximum of 5 PDF links
            if len(pdf_links) >= 5:
                break
    else:
        # Print a message if no relevant results were found
        print("No PDF results found.")

    # Ensure the function always returns a list, even if no links are found
    return pdf_links or []

def keep_smallest_pdf(folder_path):
    """
    Keep only the smallest PDF file in the specified folder by file size.

    Args:
        folder_path (str): Path to the folder containing PDF files.
    """
    # List all PDF files in the folder
    pdf_files = [f for f in os.listdir(folder_path) if f.endswith('.pdf')]

    # If no PDF files are found, exit the function
    if not pdf_files:
        return

    # Get the full path of each PDF file in the folder
    full_paths = [os.path.join(folder_path, f) for f in pdf_files]

    # Find the PDF file with the smallest size
    smallest_file = min(full_paths, key=os.path.getsize)

    # Iterate through all PDF files
    for pdf_file in full_paths:
        # Remove all files except the smallest one
        if pdf_file != smallest_file:
            os.remove(pdf_file)
            print(f"Removed larger file: {pdf_file}")  # Log the removed file for debugging

def download_pdf(url, folder_path, index):
    """
    Download a PDF from the given URL and ensure only the smallest PDF remains in the folder.

    Args:
        url (str): The URL to download the PDF from.
        folder_path (str): Path to the folder where the PDF will be saved.
        index (int): Index to include in the PDF filename for uniqueness.

    Returns:
        bool: True if the PDF is downloaded and processed successfully, False otherwise.
    """
    try:
        # Make an HTTP GET request to download the PDF
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception if the request fails

        # Create a unique filename for the downloaded PDF
        filename = f"{folder_path}/document{index}.pdf"

        # Save the downloaded content to the specified file
        with open(filename, 'wb') as file:
            file.write(response.content)
        print(f"Downloaded: {filename}")  # Log the successful download

        # After downloading, keep only the smallest PDF in the folder
        keep_smallest_pdf(folder_path)

    except Exception as e:
        # Log the error and return False to indicate failure
        print(f"Could not download {url}. Reason: {e}")
        return False

    # Return True to indicate the download and processing were successful
    return True


def encode_image(image_path):
    """
    Encode an image to a base64 string.

    Args:
        image_path (str): The file path of the image to encode.

    Returns:
        str: The base64-encoded string representation of the image content.
    """
    # Open the image file in binary read mode
    with open(image_path, "rb") as image_file:
        # Read the image content and encode it to base64
        return base64.b64encode(image_file.read()).decode("utf-8")


def image_summarize(img_base64, prompt):
    """
    Generate a summary of an image using a Large Language Model (LLM).

    Args:
        img_base64 (str): The base64-encoded string of the image.
        prompt (str): The textual prompt to guide the summary generation.

    Returns:
        str: The summary content generated by the LLM.
    """
    # Initialize the chat model with specified parameters
    chat = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Prepare the message payload to include the prompt and the base64 image
    msg = chat.invoke(
        [
            HumanMessage(
                content=[
                    {"type": "text", "text": prompt},  # Include the prompt as text input
                    {
                        "type": "image_url",  # Specify the image content type
                        "image_url": {"url": f"data:image/jpeg;base64,{img_base64}"},  # Base64-encoded image data
                    },
                ]
            )
        ]
    )
    # Return the content of the generated message
    return msg.content


def generate_img_summaries(path):
    """
    Generate base64-encoded strings and detailed summaries for images in a specified folder.

    Args:
        path (str): Path to a folder containing .jpg files. The images should be extracted and placed in this folder.

    Returns:
        tuple: A tuple containing:
            - img_base64_list (list): A list of base64-encoded strings for all .jpg images.
            - image_summaries (list): A list of detailed summaries for each image, optimized for retrieval.
    """
    # Initialize a list to store base64-encoded image strings
    img_base64_list = []

    # Initialize a list to store image summaries
    image_summaries = []

    # Prompt to guide the image summarization process
    prompt = """
        You are a chemical engineer tasked with summarizing images for retrieval.
        Bring in the chemical engineering perspectives while performing the tasks.
        Remember these images could potentially contain graphs, charts, or tables.
        These summaries will be embedded and used to retrieve the raw image for question answering.
        Give a detailed summary of the image that is well optimized for retrieval.
        Do not add additional words like Summary: etc.
    """

    # Iterate over all .jpg files in the specified folder
    for img_file in sorted(os.listdir(path)):
        if img_file.endswith(".jpg"):  # Process only .jpg files
            img_path = os.path.join(path, img_file)  # Construct the full path to the image
            base64_image = encode_image(img_path)  # Convert the image to a base64 string
            img_base64_list.append(base64_image)  # Add the base64 string to the list
            image_summaries.append(image_summarize(base64_image, prompt))  # Generate and store the image summary

    # Return the base64 strings and their corresponding summaries as a tuple
    return img_base64_list, image_summaries

def create_multi_vector_retriever(
    docstore, vectorstore, text_summaries, texts, table_summaries, tables, image_summaries, images
):
    """
    Create a multi-vector retriever that indexes summaries for retrieval but returns raw documents.

    Args:
        docstore: A document storage system to store raw content (texts, tables, or images).
        vectorstore: A vector database for indexing and retrieving based on summaries.
        text_summaries (list): Summaries for text documents to be indexed.
        texts (list): Raw text documents corresponding to the summaries.
        table_summaries (list): Summaries for table documents to be indexed.
        tables (list): Raw tables corresponding to the summaries.
        image_summaries (list): Summaries for image documents to be indexed.
        images (list): Raw images corresponding to the summaries.

    Returns:
        MultiVectorRetriever: A retriever object capable of indexing summaries and returning raw documents.
    """
    # Unique identifier key for each document
    id_key = "doc_id"

    # Instantiate the multi-vector retriever with the vectorstore and docstore
    retriever = MultiVectorRetriever(
        vectorstore=vectorstore,
        docstore=docstore,
        id_key=id_key,
    )

    # Define a helper function to add summaries and raw documents to the retriever
    def add_documents(retriever, doc_summaries, doc_contents):
        """
        Add documents and their summaries to the retriever.

        Args:
            retriever: The MultiVectorRetriever instance.
            doc_summaries (list): Summaries for the documents.
            doc_contents (list): Raw content for the documents.
        """
        # Generate unique IDs for each document
        doc_ids = [str(uuid.uuid4()) for _ in doc_contents]

        # Create document objects for summaries with metadata linking to raw documents
        summary_docs = [
            Document(page_content=s, metadata={id_key: doc_ids[i]})
            for i, s in enumerate(doc_summaries)
        ]

        # Add the summaries to the vectorstore for indexing
        retriever.vectorstore.add_documents(summary_docs)

        # Add the raw content to the docstore, linked by unique IDs
        retriever.docstore.mset(list(zip(doc_ids, doc_contents)))

    # Add text summaries and corresponding raw texts if available
    if text_summaries:
        add_documents(retriever, text_summaries, texts)

    # Add table summaries and corresponding raw tables if available
    if table_summaries:
        add_documents(retriever, table_summaries, tables)

    # Add image summaries and corresponding raw images if available
    if image_summaries:
        add_documents(retriever, image_summaries, images)

    # Return the fully initialized retriever
    return retriever


def plt_img_base64(img_base64):
    """
    Display a base64-encoded string as an image.

    Args:
        img_base64 (str): The base64-encoded string of the image to display.

    Returns:
        None
    """
    # Decode the base64 string into binary image data
    img_data = base64.b64decode(img_base64)

    # Create a BytesIO object to simulate a file-like object for the image data
    img_buffer = BytesIO(img_data)

    # Open the image using the PIL (Pillow) library
    img = Image.open(img_buffer)

    # Display the image
    display(img)


def looks_like_base64(sb):
    """
    Check if a string appears to be base64-encoded.

    Args:
        sb (str): The string to check.

    Returns:
        bool: True if the string matches the base64 format, False otherwise.
    """
    # Use a regular expression to match base64 patterns
    return re.match("^[A-Za-z0-9+/]+[=]{0,2}$", sb) is not None


def is_image_data(b64data):
    """
    Determine if the base64-encoded data represents an image by inspecting the file signature.

    Args:
        b64data (str): Base64-encoded string of the image data.

    Returns:
        bool: True if the base64 data corresponds to a recognized image format, False otherwise.
    """
    # Dictionary of common image file signatures (magic numbers) and their formats
    image_signatures = {
        b"\xff\xd8\xff": "jpg",  # JPEG
        b"\x89\x50\x4e\x47\x0d\x0a\x1a\x0a": "png",  # PNG
        b"\x47\x49\x46\x38": "gif",  # GIF
        b"\x52\x49\x46\x46": "webp",  # WebP
    }

    try:
        # Decode the base64 data and extract the first 8 bytes to check the header
        header = base64.b64decode(b64data)[:8]

        # Check if the header matches any known image signatures
        for sig, format in image_signatures.items():
            if header.startswith(sig):
                return True

        # If no matches are found, return False
        return False
    except Exception:
        # Handle decoding errors or invalid base64 data
        return False


def split_image_text_types(docs):
    """
    Split a list of documents into base64-encoded images and texts.

    Args:
        docs (list): A list of documents, where each document is either a string
                     or a `Document` object with base64-encoded image data or text.

    Returns:
        dict: A dictionary with two keys:
            - "images" (list): List of base64-encoded image strings.
            - "texts" (list): List of textual content strings.
    """
    # Initialize lists to store base64-encoded images and texts
    b64_images = []
    texts = []

    # Iterate through the provided documents
    for doc in docs:
        # If the document is of type `Document`, extract its `page_content` attribute
        if isinstance(doc, Document):
            doc = doc.page_content.decode('utf-8')  # Decode from bytes to string
        else:
            doc = doc.decode('utf-8')  # Decode plain bytes to string

        # Check if the document looks like a base64 string and is valid image data
        if looks_like_base64(doc) and is_image_data(doc):
            b64_images.append(doc)  # Add to the image list if it's valid image data
        else:
            texts.append(doc)  # Otherwise, classify it as text

    # Return the split data as a dictionary
    return {"images": b64_images, "texts": texts}


def multimodal_prompt_function(data_dict):
    """
    Create a multimodal prompt incorporating both text and image context for GPT-4o.

    This function formats the provided context from `data_dict`, which includes:
    - Textual descriptions and tables.
    - Base64-encoded images.

    It constructs a detailed prompt with text and images to guide GPT-4o in generating 
    an industrial synthesis process description for a specified chemical. The prompt 
    also includes instructions for creating a textual Process Flow Diagram (PFD) and 
    Piping and Instrumentation Diagram (P&ID).

    Args:
        data_dict (dict): A dictionary with the following structure:
            {
                "context": {
                    "texts": [list of text strings],
                    "images": [list of base64-encoded image strings]
                }
            }

    Returns:
        list: A list containing a `HumanMessage` object with formatted content.
    """
    # Combine all text content into a single formatted string
    formatted_texts = "\n".join(data_dict["context"]["texts"])
    messages = []

    # Process and add base64-encoded images to the message if present
    if data_dict["context"]["images"]:
        for image in data_dict["context"]["images"]:
            # Format the image as a base64 image URL message
            image_message = {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{image}"},
            }
            messages.append(image_message)  # Add the image message to the list

    # Construct the detailed text message with industrial synthesis instructions
    text_message = {
        "type": "text",
        "text": (
            f"""You are a chemical engineer tasked with detailing the industrial synthesis process for {{chemical_name}}. Your description must be comprehensive and cater to the needs of engineers looking to implement the process in a large-scale industrial setting. Include the following elements:

                1. **Chemical Reactions**: Describe all key chemical reactions involved in the synthesis. Clearly outline the reactants, intermediates, and final products.

                2. **Reactor Types and Operating Conditions**: Identify the types of reactors utilized (e.g., Continuous Stirred Tank Reactor (CSTR), Plug Flow Reactor (PFR)). Specify the operating conditions for each reactor type, including temperature ranges, pressure levels, and any catalyst used.

                3. **Purification Steps**: Detail any purification methods applied to achieve the desired product purity. This may include techniques like distillation, crystallization, filtration, or extraction. Describe the equipment utilized in these steps and their operating conditions.

                4. **By-product Handling**: Discuss how by-products and waste streams will be managed. Describe treatment processes, storage, or disposal methods to mitigate environmental impact.

                5. **Recycling and Heat Integration**: Include any recycling loops in the process and detail how heat integration systems are utilized to optimize energy use, such as heat exchangers that recover energy from exothermic reactions.

                ---

                **Process Flow Diagram Generation (Textual)**

                Based on the synthesis description you’ve provided, create a detailed textual Process Flow Diagram (PFD) for the synthesis of {{chemical_name}}. Your PFD should include:

                - **Major Equipment**: List and describe all major equipment at each step, such as reactors, heat exchangers, distillation columns, separators, pumps, and compressors.

                - **Material Flow**: Illustrate the flow of raw materials, intermediates, and final products through the process, including any recycling streams.

                - **Heat Integration**: Provide details on how heat integration is incorporated, including the application of heat exchangers to recover energy.

                - **Phase Representation**: Clearly depict the phases of substances (gas, liquid, solid) in each unit operation, indicating any relevant phase transitions.

                - **Operating Conditions**: Specify the operating conditions at key stages, including temperatures, pressures, and flow rates.

                - **Bottleneck Identification**: Identify potential bottlenecks in the process flow and suggest methods for optimizing throughput.

                Ensure that the PFD adheres to industry standards and is suited for large-scale production.

                ---

                **Piping and Instrumentation Diagram (P&ID) Suggestions**

                Create a detailed Piping and Instrumentation Diagram (P&ID) based on the provided Process Flow Diagram (PFD) for the synthesis of {{chemical_name}}. Your P&ID should include:

                - **Sensor Placement**: Detail where sensors (temperature, pressure, flow, and level) should be located for monitoring critical process parameters.

                - **Control Valves and Strategies**: Specify the control valves, actuators, and control loops necessary to maintain process parameters—including examples of control strategies like feedback or cascade control.

                - **Safety Instrumentation**: Identify safety instrumentation such as pressure relief valves, emergency shutdown systems, interlocks, and alarms to ensure safety compliance.

                - **Instrumentation for Optimization**: Describe instrumentation needed for process optimization, including advanced process control (APC) systems and real-time data analytics.

                - **Redundancy**: Consider redundancy and reliability in the arrangement of key sensors and control elements to enhance continuous operation.

                - **Piping Material Recommendations**: Suggest appropriate piping materials considering the compatibility, temperature, and pressure of the process streams.

                - **Control System Integration**: Recommend integration with control systems like Distributed Control Systems (DCS) or SCADA systems for centralized monitoring and control.

                Your P&ID suggestions should conform to industry best practices and standards, making it suitable for large-scale production.
            """
        ),
    }

    # Add the text message to the message list
    messages.append(text_message)

    # Wrap the messages in a HumanMessage object and return
    return [HumanMessage(content=messages)]


def multimodal_rag_qa(query, multimodal_rag_w_sources):
    """
    Perform multimodal Retrieval-Augmented Generation (RAG) for a question and display the results.

    This function queries a multimodal RAG model and displays the generated answer, 
    along with the text and image sources used for context. It also saves the answer to a CSV file.

    Args:
        query (str): The user's question or query to be answered by the RAG model.
        multimodal_rag_w_sources (object): A multimodal RAG model object that supports 
                                           the `invoke` method to generate answers.

    Returns:
        None
    """
    # Invoke the multimodal RAG model with the query
    response = multimodal_rag_w_sources.invoke({'input': query})
    
    # Extract the generated answer from the response
    answer = response['answer']

    # Display the answer
    print('==' * 50)
    print('Answer:')
    display(Markdown(answer))  # Display the answer in Markdown format

    # Save the answer to a CSV file for record-keeping
    save_answer_to_csv(answer)

    # Display the sources used to generate the answer
    print('--' * 50)
    print('Sources:')
    
    # Extract text and image sources from the response
    text_sources = response['context']['texts']
    img_sources = response['context']['images']

    # Display each text source
    for text in text_sources:
        display(Markdown(text))  # Display text sources in Markdown format
        print()

    # Display each image source by decoding and rendering the base64 image
    for img in img_sources:
        plt_img_base64(img)  # Function to display base64-encoded images
        print()

    # End of output
    print('==' * 50)

def save_answer_to_csv(answer, filename='pdf_response.csv'):
    """
    Save the provided answer to a CSV file.

    This function appends the given answer to a CSV file in a specified directory. 
    If the directory does not exist, it is created automatically. The file header 
    is included only when the file is newly created.

    Args:
        answer (str): The answer text to be saved in the CSV file.
        filename (str): The name of the CSV file. Default is 'pdf_response.csv'.

    Returns:
        None
    """
    # Define the output directory for storing CSV files
    output_directory = "agents_output"
    
    # Create the output directory if it does not already exist
    os.makedirs(output_directory, exist_ok=True)

    # Construct the full path for the CSV file
    csv_file_path = os.path.join(output_directory, filename)

    # Create a DataFrame containing the answer
    df = pd.DataFrame({'Answer': [answer]})

    # Append the DataFrame to the CSV file.
    # Add a header only if the file does not already exist.
    df.to_csv(
        csv_file_path, 
        index=False, 
        mode='a',  # Append mode to add data without overwriting
        header=not pd.io.common.file_exists(csv_file_path)  # Add header only for new files
    )

    # Inform the user that the answer has been saved successfully
    print(f"Answer saved to: {csv_file_path}")


def main(query):
    """
    Main function to perform multimodal retrieval-augmented generation (RAG) for a given query.

    This function handles the entire pipeline:
    1. Searching and downloading PDFs using a search engine.
    2. Processing PDFs to extract text, tables, and images.
    3. Summarizing extracted content for semantic retrieval.
    4. Indexing summarized data into a vectorstore and creating a multi-vector retriever.
    5. Handling a multimodal RAG query with text, table, and image sources.

    Args:
        query (str): The user's query to be used throughout the pipeline.

    Returns:
        None
    """
    API_KEY = os.getenv('SERP_API_KEY')  # Retrieve API key from environment variables

    # Directory to store downloaded PDFs
    pdf_folder_path = "DownloadedPDFs"
    os.makedirs(pdf_folder_path, exist_ok=True)  # Create the directory if it doesn't exist

    # Search and download PDFs
    pdf_links = search_pdfs(query, API_KEY)

    # Download and save PDFs
    for index, pdf_url in enumerate(pdf_links, start=1):
        success = download_pdf(pdf_url, pdf_folder_path, index)
        if not success:
            print(f"Skipping failed download for {pdf_url}")
            continue  # Skip to the next URL if download fails

    # List all PDF files in the folder
    pdf_files = [f for f in os.listdir(pdf_folder_path) if f.endswith('.pdf')]
    print(f"Found {len(pdf_files)} PDF files.")

    # Initialize lists for documents and tables
    docs = []
    tables = []

    # Process each PDF file to extract elements
    for pdf_file in pdf_files:
        doc_path = os.path.join(pdf_folder_path, pdf_file)  # Full path to the PDF file
        print(f"Processing {doc_path}...")

        # Load the PDF using UnstructuredPDFLoader with configuration
        loader = UnstructuredPDFLoader(
            file_path=doc_path,
            strategy='hi_res',
            extract_images_in_pdf=True,
            infer_table_structure=True,
            chunking_strategy="by_title",
            max_characters=4000,
            new_after_n_chars=4000,
            combine_text_under_n_chars=2000,
            mode='elements',
            image_output_dir_path='./figures'
        )
        data = loader.load()
        print(f"Loaded {len(data)} elements from {pdf_file}.")

        # Classify and store extracted elements
        for doc in data:
            if doc.metadata['category'] == 'Table':
                tables.append(doc)
            elif doc.metadata['category'] == 'CompositeElement':
                docs.append(doc)

    print(f"Total documents: {len(docs)}, Total tables: {len(tables)}")

    # Convert tables to Markdown format
    for table in tables:
        table.page_content = htmltabletomd.convert_table(table.metadata['text_as_html'])
        print(table.page_content)

    # Summarization prompt for text and tables
    prompt_text = """
    You are a chemical engineer tasked with summarizing tables and text particularly for semantic retrieval.
    Bring in the chemical engineering perspectives while performing the tasks.
    These summaries will be embedded and used to retrieve the raw text or table elements.
    Give a detailed summary of the table or text below that is well optimized for retrieval.
    For any tables also add in a one-line description of what the table is about besides the summary.
    Do not add additional words like Summary: etc.

    Table or text chunk:
    {element}
    """
    prompt = ChatPromptTemplate.from_template(prompt_text)

    # Define summarization chain
    summarize_chain = (
        {"element": RunnablePassthrough()}
        | prompt
        | chatgpt
        | StrOutputParser()  # Parses the response as text
    )

    # Summarize text and tables
    text_docs = [doc.page_content for doc in docs]
    table_docs = [table.page_content for table in tables]

    text_summaries = summarize_chain.batch(text_docs, {"max_concurrency": 5})
    table_summaries = summarize_chain.batch(table_docs, {"max_concurrency": 5})

    print(f"Text summaries: {len(text_summaries)}, Table summaries: {len(table_summaries)}")

    # Process images
    IMG_PATH = './figures'
    imgs_base64, image_summaries = generate_img_summaries(IMG_PATH)
    print(f"Images: {len(imgs_base64)}, Image summaries: {len(image_summaries)}")

    # Index summaries into a vectorstore
    chroma_db = Chroma(
        collection_name="mm_rag",
        embedding_function=openai_embed_model,
        collection_metadata={"hnsw:space": "cosine"},
    )

    # Initialize a Redis store for raw data storage
    client = get_client('redis://localhost:6379')
    redis_store = RedisStore(client=client)

    # Create a multi-vector retriever
    retriever_multi_vector = create_multi_vector_retriever(
        redis_store,
        chroma_db,
        text_summaries,
        text_docs,
        table_summaries,
        table_docs,
        image_summaries,
        imgs_base64,
    )
    print(retriever_multi_vector)

    # Example query to test retrieval
    query = "Tell me detailed answer on how to make a PFD and P&ID of the given compound"
    docs = retriever_multi_vector.invoke(query, limit=5)
    print(f"Retrieved {len(docs)} documents.")

    # Create a RAG chain for multimodal retrieval
    multimodal_rag = (
        {
            "context": itemgetter('context'),
            "question": itemgetter('input'),
        }
        | RunnableLambda(multimodal_prompt_function)
        | chatgpt
        | StrOutputParser()
    )

    # Retrieve context elements for a multimodal query
    retrieve_docs = (itemgetter('input')
                     | retriever_multi_vector
                     | RunnableLambda(split_image_text_types))

    # Assign context and generate the answer for multimodal retrieval
    multimodal_rag_w_sources = (
        RunnablePassthrough.assign(context=retrieve_docs)
        .assign(answer=multimodal_rag)
    )

    # Perform multimodal RAG Q&A
    query = "Tell me detailed answer on how to make a PFD and P&ID of the given compound"
    answer = multimodal_rag_qa(query, multimodal_rag_w_sources)
