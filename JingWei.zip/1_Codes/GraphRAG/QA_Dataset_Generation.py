

import os
import re
import sys
import json
import openai
#import anthropic
import logging
import pdfplumber

################# sagarsrinivasnvidia1@yahoo.com
'''
# REQUIREMENTS: pip install PyPDF2 pdfplumber
'''

# Set up logging to print logs to stdout and ensure visibility
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

# Define an error handler decorator to handle exceptions and log errors
def error_handler(func):
    """
    A decorator to handle errors during function execution.
    Logs specific exceptions and provides fallback mechanisms.
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except openai.RateLimitError as e:
            logging.error(f"Rate limit exceeded in {func.__name__}: {str(e)}. Please try again later.")
            return None
        except openai.Timeout as e:
            logging.error(f"Timeout occurred in {func.__name__}: {str(e)}. The request took too long to complete.")
            return None
        except openai.APIError as e:
            logging.error(f"API error occurred in {func.__name__}: {str(e)}. Please check the API call.")
            return None
        except openai.OpenAIError as e:
            logging.error(f"OpenAI error occurred in {func.__name__}: {str(e)}. Please check your request and API settings.")
            return None
        except FileNotFoundError as e:
            logging.error(f"File not found: {str(e)}. Please check the file path.")
            return None
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error: {str(e)}. Please check the file format.")
            return None
        except Exception as e:
            logging.error(f"Unexpected error occurred in {func.__name__}: {str(e)}")
            return None
    return wrapper

@error_handler
def process_chemical_synthesis_from_pdf(gpt4_client, nvidia_client, pdf_file_path, num_questions, threshold=3.0):
    try:
        # Open and read the PDF file
        with pdfplumber.open(pdf_file_path) as pdf:
            pdf_text = ""
            for page in pdf.pages:
                pdf_text += page.extract_text()

    except FileNotFoundError:
        logging.error(f"The file {pdf_file_path} could not be found.")
        return None

    # Extract relevant sections from the PDF text using pattern matching
    synthesis_description_match = re.search(r'Synthesis Description(.+?)Process Flow Diagram', pdf_text, re.S)
    pfd_description_match = re.search(r'Process Flow Diagram(.+?)Piping and Instrumentation Diagram', pdf_text, re.S)
    pid_suggestions_match = re.search(r'Piping and Instrumentation Diagram(.+?)$', pdf_text, re.S)

    # Extract and clean the matched sections
    synthesis_description = synthesis_description_match.group(1).strip() if synthesis_description_match else ""
    pfd_description = pfd_description_match.group(1).strip() if pfd_description_match else ""
    pid_suggestions = pid_suggestions_match.group(1).strip() if pid_suggestions_match else ""


    QUESTION_PROMPT_TEMPLATE = f"""\
    Generate exactly {num_questions} questions whose answers are strictly grounded in the context of the Process Flow Diagram (PFD) and Piping and Instrumentation Diagram (P&ID)
    provided below. The questions should focus on understanding, interpretation, design, and analysis based on textual descriptions of the given diagrams. If any question is not grounded in
    the context of the PFD or P&ID, it is considered an invalid question. The questions must strictly focus on the following categories: Conceptual Understanding,
    Interpretation, Design and Engineering, and Analytical Thinking.**

    Process Flow Diagram: {{pfd_description}}

    Piping and Instrumentation Diagram: {{pid_description}}

    **Rules (to be strictly followed):**
    - You must generate exactly {num_questions} questions. No more, no fewer.
    - Do not include any introductions, explanations, or summaries. **Only output questions.**
    - Do not use any phrases such as "Here are the questions" or "Based on the diagrams."
    - Do not include any numbers, bullet points, or any other symbols.
    - Each question must end with a question mark and be followed by a single newline character (\n).
    - If any text other than the questions is generated, it is invalid output.
    - If any question is not grounded in the provided context, it is invalid output.
    - Do not include any specific references to steps, phases, or particular stages of the process, such as "Steps 1-3" or any other specific numbering.

    """
  
    @error_handler
    def generate_questions_gpt4(client, pfd_description, pid_description):
        prompt = QUESTION_PROMPT_TEMPLATE.format(
            pfd_description=pfd_description,
            pid_description=pid_description
        )
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with thoughtful and logical questions focusing on the Process Flow Diagram (PFD), and Piping and Instrumentation Diagram (P&ID)."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

   
    questions_gpt4 = generate_questions_gpt4(gpt4_client, pfd_description, pid_suggestions)

    ANSWER_PROMPT_TEMPLATE = """\
    Provide clear, accurate, and concise answers to the following questions. Adhere strictly to the following rules to ensure very high scores in the following categories: 

    1. **Helpfulness:** Ensure each answer is extremely helpful, fully addressing the question in a way that resolves the query effectively.
    2. **Correctness:** Every answer must be factually correct, accurately referencing relevant details.
    3. **Coherence:** Ensure that each answer is logically structured and flows smoothly, making it easy for the reader to follow.
    4. **Complexity:** Balance complexity appropriately; provide necessary depth without making the answer overly complicated. Ensure the response is insightful where needed.
    5. **Verbosity:** Be concise but thorough. Include all essential details without adding unnecessary information. Ensure that the length of the answer aligns perfectly with the complexity of the question.
    
    Generate answers that are strictly grounded in the context provided below. Your answers must reference relevant details from the Synthesis Description,
    Process Flow Diagram (PFD), and Piping and Instrumentation Diagram (P&ID). If any answer is not based on these contexts, it is considered invalid.    
    Failure to adhere to these rules will lead to lower scores and suboptimal performance.

    Synthesis Description: {synthesis_description}

    Process Flow Diagram: {pfd_description}

    Piping and Instrumentation Diagram: {pid_description}

    Questions:
    {questions}

    """

    @error_handler
    def generate_answers_gpt4(client, synthesis_description, pfd_description, pid_description, question):
        prompt = ANSWER_PROMPT_TEMPLATE.format(
            synthesis_description=synthesis_description,
            pfd_description=pfd_description,
            pid_description=pid_description,
            questions=question
        )
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert in chemical engineering. Respond with thoughtful and logical answers focusing on the Process Flow Diagram (PFD), and Piping and Instrumentation Diagram (P&ID)."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    @error_handler
    def evaluate_content(client, model, content, prompt):
        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": content},
        ]
        response = client.chat.completions.create(model=model, messages=messages)
        scores = response.choices[0].logprobs.content
        return {"response": content, "scores": scores}

    qa_prompt= """\ 
                Evaluate the quality of the provided answer to the question based on the following criteria: Helpfulness, Correctness, Coherence, Complexity, Verbosity.
               """

    def process_qa_pairs(questions, generate_answers_func, evaluate_content_func, client, synthesis_description, pfd_description, pid_description, qa_prompt):

        filtered_qa_pairs = []

        for question in questions.split('\n\n'):  # Assuming each question is separated by a newline

            answer = generate_answers_func(client, synthesis_description, pfd_description, pid_description, question)
            qa_content_score = evaluate_content_func(nvidia_client, "nvidia/nemotron-4-340b-reward", answer, qa_prompt)

            scores = qa_content_score["scores"]
            
            # Extract the logprob scores
            score_dict = {
                "helpfulness": get_logprob(scores, "helpfulness"),
                "correctness": get_logprob(scores, "correctness"),
                "coherence": get_logprob(scores, "coherence"),
                "complexity": get_logprob(scores, "complexity"),
                "verbosity": get_logprob(scores, "verbosity"),
            }

            # Filter based on the threshold
            if score_dict["helpfulness"] >= threshold:
                filtered_qa_pairs.append({"question": question, "answer": answer, "scores": score_dict})

        return filtered_qa_pairs

    # Process QA pairs for GPT-4 and Claude
    filtered_qa_gpt4 = process_qa_pairs(questions_gpt4, generate_answers_gpt4, evaluate_content, gpt4_client, synthesis_description, pfd_description, pid_suggestions, qa_prompt)

    # Extract the chemical name from the pdf_file_path (assuming it's in the filename)
    chemical_name = os.path.splitext(os.path.basename(pdf_file_path))[0]

    # Prepare the data to be saved
    synthesis_pipeline = {
        "chemical_name": chemical_name,
        "questions_answers_gpt4": filtered_qa_gpt4
    }

    # Define the directory where JSON files will be saved
    data_directory = "data_QA"

    # Create the directory if it doesn't exist
    os.makedirs(data_directory, exist_ok=True)

    # Save the filtered data and scores in the JSON file within the data directory
    output_json_file = os.path.join(data_directory, f"{chemical_name}_synthesis_pipeline_filtered.json")
    with open(output_json_file, 'w') as f:
        json.dump(synthesis_pipeline, f, indent=4)

    logging.info(f"Synthesis pipeline for {chemical_name} updated and saved successfully.")

@error_handler
def get_logprob(scores, token_name):
    return next((score.logprob for score in scores if score.token == token_name), 0)

# Example usage
openai_client = openai.OpenAI(api_key="")
nvidia_client = openai.OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key="")

# Function to process all PDF files in a given directory
@error_handler
def process_directory_of_pdfs(gpt4_client, nvidia_client, directory_path, num_questions, threshold=3.0):
    # Loop through all files in the directory
    for filename in os.listdir(directory_path):
        if filename.endswith(".pdf"):
            pdf_file_path = os.path.join(directory_path, filename)
            logging.info(f"Processing PDF: {pdf_file_path}")
            # Process each PDF file
            process_chemical_synthesis_from_pdf(gpt4_client, nvidia_client, pdf_file_path, num_questions, threshold)
        else:
            logging.warning(f"Skipped non-PDF file: {filename}")

# Directory containing PDF files
pdf_directory_path = 'data'

# User-defined number of questions
num_questions = 6000

# Run the pipeline on all PDFs in the directory
process_directory_of_pdfs(
    gpt4_client=openai_client,
    nvidia_client=nvidia_client,
    directory_path=pdf_directory_path,
    num_questions=num_questions,
    threshold=1.0
)

