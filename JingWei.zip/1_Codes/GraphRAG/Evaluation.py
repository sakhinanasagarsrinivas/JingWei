# To display all relationships in a Neo4j database
'''
MATCH (n)-[r]->(m)
RETURN n, r, m
'''

# To delete all nodes in a Neo4j database using Cypher, you can use the following query:
''' 
MATCH (n)
DETACH DELETE n;
'''

# pip install llama-index-llms-ollama
# ollama run llama3.2:1b-instruct-fp16
# ollama run llama3.2:3b-instruct-fp16

import warnings
warnings.filterwarnings('ignore')

import os
import sys
import json
import pickle
import logging
# Suppress Neo4j warning logs
logging.getLogger("neo4j.notifications").setLevel(logging.ERROR)

import requests
from typing import List
from neo4j import GraphDatabase
#from llama_index.llms.anthropic import Anthropic
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from llama_parse import LlamaParse
from copy import deepcopy
#from llama_index.llms.groq import Groq
from llama_index.core.schema import Document
from llama_index.core.indices.property_graph import (
    ImplicitPathExtractor,
    SimpleLLMPathExtractor,
)
from llama_index.core import PropertyGraphIndex
from llama_index.graph_stores.neo4j import Neo4jPGStore
from llama_index.core import VectorStoreIndex
from llama_index.core.indices.property_graph import VectorContextRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.agent import FunctionCallingAgentWorker
from requests.exceptions import ConnectionError, Timeout
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

#####################################################################

#############  Setup Model
# Define or load your LLM

# Set up API keys and LLM settings
os.environ['OPENAI_API_KEY'] = 'sk-UYEMtGsVCFq5vjOQXLPI5uUTmzd4SdK2KqQ5-5uPiJT3BlbkFJi-De-4Bx4lt1GTTR9Y9Adjye7boXTu5XgMU-wQfBYA'

llm = OpenAI(model="gpt-4o-mini", temperature=0.2, max_tokens=4096, top_p=1.0, frequency_penalty=0.0, presence_penalty=0.0)
embed_model = OpenAIEmbedding(model="text-embedding-3-small")

Settings.llm = llm
Settings.embed_model = embed_model
Settings.chunk_size = 1024
Settings.chunk_overlap = 512

#####################################################################

'''
Auxiliary Functions
'''

def load_sub_docs(file_name):
    """
    Load sub-documents from a file using the pickle library.

    Args:
        file_name (str): The name of the file to load sub-documents from.

    Returns:
        Any: The deserialized object loaded from the file.

    Raises:
        IOError: If the file cannot be opened or read.
    """
    try:
        with open(file_name, "rb") as f:
            return pickle.load(f)
    except IOError as e:
        logging.error("Error loading sub-documents from file: %s", e)
        raise


def setup_graph_store():
    """
    Initialize and return a connection to the Neo4j property graph store.
    Checks if the graph store already contains nodes.

    Returns:
        tuple: A tuple containing the Neo4j property graph store and a boolean 
               indicating whether the store already contains nodes.

    Raises:
        ConnectionError: If unable to connect to the Neo4j database.
        TimeoutError: If the connection to Neo4j times out.
        Exception: For any other errors encountered during initialization.
    """
    # Credentials for Neo4j
    neo4j_url = "neo4j+s://4ec5c2b0.databases.neo4j.io"
    neo4j_username = "neo4j"
    neo4j_password = "kJsI9hcuzSqYb4wO-eIJRrZ1ss0zF1HhFjQlVcGce2k"

    try:
        # Establish a direct connection to the Neo4j database using the Neo4j driver
        driver = GraphDatabase.driver(neo4j_url, auth=(neo4j_username, neo4j_password))

        # Check if the graph store already has nodes
        with driver.session() as session:
            cypher_query = "MATCH (n) RETURN count(n) AS node_count LIMIT 1"
            result = session.run(cypher_query)
            node_count = result.single()["node_count"]

            if node_count > 0:
                logging.info(f"Graph store already contains {node_count} nodes.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url), True
            else:
                logging.info("Graph store is empty. No nodes found.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url), False

    except ConnectionError as e:
        logging.error("Failed to connect to Neo4j graph store: %s", e)
        raise
    except TimeoutError as e:
        logging.error("Connection to Neo4j graph store timed out: %s", e)
        raise
    except Exception as e:
        logging.error("An error occurred while checking the graph store: %s", e)
        raise


# Initialize graph store and check if it has nodes
graph_store, has_nodes = setup_graph_store()

# Only run load_and_create_index if there are nodes in the graph store
if has_nodes:
    print("Graph store already populated, skipping index creation.")

    # Run this if the index is already loaded
    index = PropertyGraphIndex.from_existing(
        graph_store,
        show_progress=True,
    )


def fetch_details(user_question):
    """
    Retrieve information on Process Flow Diagrams (PFDs) and Piping and Instrumentation Diagrams (P&IDs)
    based on a user question using a property graph index and a custom retriever.

    Args:
        user_question (str): The user's query to be processed.

    Returns:
        str: The response generated by the agent based on the user's query.

    Raises:
        Exception: If an error occurs during the response generation process.
    """
    try:
        # Step 1: Set up the KG vector retriever
        def setup_vector_retriever(index):
            """
            Set up a vector retriever for the provided index.

            Args:
                index (PropertyGraphIndex): The index to retrieve from.

            Returns:
                VectorContextRetriever: The configured vector retriever.

            Raises:
                Exception: If the retriever setup fails.
            """
            try:
                return VectorContextRetriever(
                    index.property_graph_store,
                    embed_model=Settings.embed_model,
                    similarity_top_k=4,
                    path_depth=1,
                    include_text=True,
                )
            except Exception as e:
                logging.error("Error setting up vector retriever: %s", e)
                raise

        # Step 2: Custom retriever class that combines KG and direct vector search
        class CustomRetriever(BaseRetriever):
            """
            Custom retriever that combines knowledge graph vector retrieval with direct vector retrieval.
            """
            def __init__(self, kg_retriever, vector_retriever):
                self._kg_retriever = kg_retriever
                self._vector_retriever = vector_retriever

            def _retrieve(self, query_bundle) -> List[NodeWithScore]:
                """
                Perform retrieval by combining results from the KG and vector retrievers.

                Args:
                    query_bundle (QueryBundle): The query to be executed.

                Returns:
                    List[NodeWithScore]: A list of unique nodes retrieved.

                Raises:
                    Exception: If retrieval fails.
                """
                try:
                    kg_nodes = self._kg_retriever.retrieve(query_bundle)
                    vector_nodes = self._vector_retriever.retrieve(query_bundle)

                    unique_nodes = {n.node_id: n for n in kg_nodes}
                    unique_nodes.update({n.node_id: n for n in vector_nodes})
                    return list(unique_nodes.values())
                except Exception as e:
                    logging.error("Error during retrieval: %s", e)
                    raise

        # Step 3: Set up the KG retriever and base vector retriever
        kg_retriever = setup_vector_retriever(index)
        sub_docs = load_sub_docs("sub_docs.pkl")
        base_retriever = VectorStoreIndex.from_documents(sub_docs, embed_model=Settings.embed_model).as_retriever(similarity_top_k=4)
        custom_retriever = CustomRetriever(kg_retriever, base_retriever)

        # Step 4: Build the agent with the custom retriever
        kg_query_engine = RetrieverQueryEngine(custom_retriever)
        kg_query_tool = QueryEngineTool(
            query_engine=kg_query_engine,
            metadata=ToolMetadata(
                name="query_tool",
                description="Provides information on Process Flow Diagrams (PFDs) and Piping and Instrumentation Diagrams (P&IDs) used in industrial-scale chemical production.",
            ),
        )
        agent_worker = FunctionCallingAgentWorker.from_tools(
            [kg_query_tool],
            llm=Settings.llm,
            verbose=True,
            allow_parallel_tool_calls=False,
        )
        agent = agent_worker.as_agent()
        
        # Step 5: Run the agent with the user's question
        agent.reset()
        response = agent.chat(user_question)
        return response
    except Exception as e:
        logging.error("Error during agent response generation: %s", e)
        raise


import json

# Path to the combined JSON file
combined_json_file = 'data_QA/combined_synthesis_pipeline.json'

try:
    # Open the combined JSON file and load its content
    with open(combined_json_file, 'r') as f:
        combined_data = json.load(f)
        print("Successfully loaded combined JSON file.")
except FileNotFoundError:
    # Handle the case where the file is not found
    print(f"File {combined_json_file} not found.")
except json.JSONDecodeError as e:
    # Handle JSON decoding errors
    print(f"Error decoding JSON from file {combined_json_file}: {e}")
except Exception as e:
    # Handle any other exceptions
    print(f"An error occurred: {e}")

# List to store the final output, which includes questions, answers, and responses
final_output = []

# Example: Iterate through the question-answer pairs for each chemical
if combined_data:
    for chemical_data in combined_data:
        # Extract the chemical name or use a default value if not present
        chemical_name = chemical_data.get('chemical_name', 'Unknown chemical')
        print(f"\nChemical: {chemical_name}")
        
        # Accessing the question-answer pairs associated with this chemical
        questions_answers = chemical_data.get('questions_answers_gpt4', [])

        # Initialize a list to hold Q&A and response data for this chemical
        chemical_output = {
            'chemical_name': chemical_name,
            'questions_answers_responses': []
        }
        
        for idx, qa in enumerate(questions_answers, 1):
            # Extract the question and answer or use default placeholders if not present
            question = qa.get('question', 'No question provided')
            answer = qa.get('answer', 'No answer provided')

            # Call the function to fetch details based on the question
            response = fetch_details(question)

            # Append the question, answer, and generated response to the list
            chemical_output['questions_answers_responses'].append({
                'question': question,
                'answer': answer,
                'response': response.response  # Assuming response has a 'response' attribute
            })

            # Append the chemical's data to the final output list
            final_output.append(chemical_output)

# Save the final output to a new JSON file
output_file = 'data_QA/combined_questions_answers_responses.json'

try:
    with open(output_file, 'w') as outfile:
        # Write the final output to a JSON file with an indentation of 4 for readability
        json.dump(final_output, outfile, indent=4)
    print(f"Combined question-answer-response JSON saved to {output_file}")
except Exception as e:
    # Handle errors encountered during writing to the file
    print(f"Error writing to output file: {e}")
