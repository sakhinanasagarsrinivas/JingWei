import os
import json

# Directory containing the JSON files
directory = 'data_QA'

# Initialize a generator to yield JSON content from all files with error handling
def read_json_files(directory):
    for filename in os.listdir(directory):
        # Check if the file ends with .json
        if filename.endswith('.json'):
            file_path = os.path.join(directory, filename)
            try:
                # Attempt to open and parse the JSON file
                with open(file_path, 'r') as f:
                    print(f"Processing file: {filename}")
                    yield json.load(f)
            except json.JSONDecodeError as e:
                print(f"Error decoding JSON in file {filename}: {e}")
            except Exception as e:
                print(f"Error reading file {filename}: {e}")

# Specify the output file
output_file = 'data_QA/combined_synthesis_pipeline.json'

try:
    # Write the combined data directly to the output file
    with open(output_file, 'w') as outfile:
        combined_data = list(read_json_files(directory))  # Collect all data
        if combined_data:
            json.dump(combined_data, outfile, indent=4)  # Write it as a single JSON file
            print(f"Combined JSON saved to {output_file}")
        else:
            print("No valid JSON files were found or processed.")
except Exception as e:
    print(f"Error writing to output file: {e}")
