# To display all relationships in a Neo4j database
'''
MATCH (n)-[r]->(m)
RETURN n, r, m
'''

# To delete all nodes in a Neo4j database using Cypher, you can use the following query:
''' 
MATCH (n)
DETACH DELETE n;
'''

# pip install llama-index-llms-ollama
# ollama run llama3.2:1b-instruct-fp16
# ollama run llama3.2:3b-instruct-fp16
# REQUIREMENTS: pip install PyPDF2 pdfplumber

import warnings
warnings.filterwarnings('ignore')

import os
import sys
import json
import pickle
import logging
import pdfplumber

# Suppress Neo4j warning logs
logging.getLogger("neo4j.notifications").setLevel(logging.ERROR)

import requests
from typing import List
from neo4j import GraphDatabase
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from llama_parse import LlamaParse
from copy import deepcopy
from llama_index.llms.ollama import Ollama
from llama_index.core.schema import Document
from llama_index.core.indices.property_graph import (
    ImplicitPathExtractor,
    SimpleLLMPathExtractor,
)
from llama_index.core import PropertyGraphIndex
from llama_index.graph_stores.neo4j import Neo4jPGStore
from llama_index.core import VectorStoreIndex
from llama_index.core.indices.property_graph import VectorContextRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.agent import FunctionCallingAgentWorker
from requests.exceptions import ConnectionError, Timeout

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

#####################################################################

#############  Setup Model
# Define or load your LLM

# Set up API keys and LLM settings
os.environ['OPENAI_API_KEY'] = 'sk-UYEMtGsVCFq5vjOQXLPI5uUTmzd4SdK2KqQ5-5uPiJT3BlbkFJi-De-4Bx4lt1GTTR9Y9Adjye7boXTu5XgMU-wQfBYA'

llm = OpenAI(model="gpt-4o-mini", temperature=0.2, max_tokens=8092, top_p=1.0, frequency_penalty=0.0, presence_penalty=0.0)
embed_model = OpenAIEmbedding(model="text-embedding-3-small")

Settings.llm = llm
Settings.embed_model = embed_model
Settings.chunk_size = 3072
Settings.chunk_overlap = 1024

#####################################################################

'''
Auxiliary Functions
'''

def save_sub_docs(sub_docs, file_name):
    """Save the sub-documents to a file using pickle."""
    try:
        with open(file_name, "wb") as f:
            pickle.dump(sub_docs, f)
    except IOError as e:
        logging.error("Error saving sub-documents to file: %s", e)
        raise

def load_sub_docs(file_name):
    """Load sub-documents from a file."""
    try:
        with open(file_name, "rb") as f:
            return pickle.load(f)
    except IOError as e:
        logging.error("Error loading sub-documents from file: %s", e)
        raise

def setup_graph_store():
    """Initialize and return a connection to the Neo4j property graph store, and check if it already has nodes."""

    # Credentials for Neo4j
    neo4j_url = "neo4j+s://4ec5c2b0.databases.neo4j.io"
    neo4j_username = "neo4j"
    neo4j_password = "kJsI9hcuzSqYb4wO-eIJRrZ1ss0zF1HhFjQlVcGce2k"

    try:
        # Establish a direct connection to the Neo4j database using the Neo4j driver
        driver = GraphDatabase.driver(neo4j_url, auth=(neo4j_username, neo4j_password))

        # Check if the graph store already has nodes
        with driver.session() as session:
            cypher_query = "MATCH (n) RETURN count(n) AS node_count LIMIT 1"
            result = session.run(cypher_query)
            node_count = result.single()["node_count"]

            if node_count > 0:
                logging.info(f"Graph store already contains {node_count} nodes.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url,), True  # Return the driver and flag indicating the graph has nodes
            else:
                logging.info("Graph store is empty. No nodes found.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url,), False  # Return the driver and flag indicating the graph is empty

    except ConnectionError as e:
        logging.error("Failed to connect to Neo4j graph store: %s", e)
        raise
    except TimeoutError as e:
        logging.error("Connection to Neo4j graph store timed out: %s", e)
        raise
    except Exception as e:
        logging.error("An error occurred while checking the graph store: %s", e)
        raise

def load_and_create_index(directory_path, graph_store, persist_dir="./storage"):
    """
    Load and parse all PDF files in a directory, split documents into sub-documents,
    and create a PropertyGraphIndex from the parsed documents.

    Args:
        directory_path (str): Path to the directory containing PDF files.
        graph_store (Neo4jPGStore): Connection to the Neo4j property graph store.
        embed_model (OpenAIEmbedding): Embedding model for vectorization.
        persist_dir (str): Directory to persist the created index.
    
    Returns:
        PropertyGraphIndex: Constructed property graph index.
    """

    all_docs = []
    
    # Step 1: Load and parse PDFs
    for file_name in os.listdir(directory_path):
        if file_name.endswith(".pdf"):
            file_path = os.path.join(directory_path, file_name)
            try:
                # Open and read the PDF file
                with pdfplumber.open(file_path) as pdf:
                    pdf_text = ""
                    for page in pdf.pages:
                        pdf_text += page.extract_text()
                if not pdf_text:
                    logging.warning(f"No documents found in {file_path}.")
                all_docs.append(pdf_text)
            except FileNotFoundError as e:
                logging.error("File not found: %s", file_path)
                raise
            except Exception as e:
                logging.error("An error occurred while parsing the PDF: %s", e)
                raise

    if not all_docs:
        logging.warning("No documents parsed from PDFs. Check your PDF files.")
        return None

    # Step 2: Split documents into sub-documents
    sub_docs = []
    for doc in all_docs:
        if doc.strip():  # Ensure it's not an empty chunk
            sub_doc = Document(
                text=doc,
            )
            sub_docs.append(sub_doc)
    save_sub_docs(sub_docs, "sub_docs.pkl")
    if not sub_docs:
        logging.warning("No sub-documents were created after splitting the documents.")
        return None

    # Step 3: Create PropertyGraphIndex
    index = PropertyGraphIndex.from_documents(
            sub_docs,
            embed_model=Settings.embed_model,
            kg_extractors=[
                ImplicitPathExtractor(),
                SimpleLLMPathExtractor(
                    llm=Settings.llm,
                    num_workers=4,
                    max_paths_per_chunk=30,
                ),
            ],
            property_graph_store=graph_store,
            show_progress=True,
        )
    os.makedirs(persist_dir, exist_ok=True)
    index.storage_context.persist(persist_dir=persist_dir)
    return index

# Initialize graph store and check if it has nodes
graph_store, has_nodes = setup_graph_store()

# Entity deduplication in the knowledge graph
def entity_deduplication(graph_store):
    """
    Perform entity deduplication by creating a vector index and removing duplicate entities in the knowledge graph.
    """
    try:
        # Create vector index for entity deduplication
        graph_store.structured_query("""
        CREATE VECTOR INDEX entity IF NOT EXISTS
        FOR (m:`__Entity__`)
        ON m.embedding
        OPTIONS {indexConfig: {
        `vector.dimensions`: 1536,
        `vector.similarity_function`: 'cosine'
        }}
        """)

        # Set similarity threshold and edit distance
        similarity_threshold = 0.9
        word_edit_distance = 5

        # Query for duplicate entities based on vector similarity and edit distance
        data = graph_store.structured_query("""
        MATCH (e:__Entity__)
        CALL {
            WITH e
            CALL db.index.vector.queryNodes('entity', 10, e.embedding)
            YIELD node, score
            WITH node, score
            WHERE score > toFLoat($cutoff)
                AND (toLower(node.name) CONTAINS toLower(e.name) OR toLower(e.name) CONTAINS toLower(node.name)
                    OR apoc.text.distance(toLower(node.name), toLower(e.name)) < $distance)
                AND labels(e) = labels(node)
            WITH node, score
            ORDER BY node.name
            RETURN collect(node) AS nodes
        }
        WITH distinct nodes
        WHERE size(nodes) > 1
        WITH collect([n in nodes | n.name]) AS results
        UNWIND range(0, size(results)-1, 1) as index
        WITH results, index, results[index] as result
        WITH apoc.coll.sort(reduce(acc = result, index2 IN range(0, size(results)-1, 1) |
                CASE WHEN index <> index2 AND
                    size(apoc.coll.intersection(acc, results[index2])) > 0
                    THEN apoc.coll.union(acc, results[index2])
                    ELSE acc
                END
        )) as combinedResult
        WITH distinct(combinedResult) as combinedResult
        // extra filtering
        WITH collect(combinedResult) as allCombinedResults
        UNWIND range(0, size(allCombinedResults)-1, 1) as combinedResultIndex
        WITH allCombinedResults[combinedResultIndex] as combinedResult, combinedResultIndex, allCombinedResults
        WHERE NOT any(x IN range(0,size(allCombinedResults)-1,1)
            WHERE x <> combinedResultIndex
            AND apoc.coll.containsAll(allCombinedResults[x], combinedResult)
        )
        RETURN combinedResult
        """, param_map={'cutoff': similarity_threshold, 'distance': word_edit_distance})

        for row in data:
            print(row)

        # Merge duplicate nodes
        graph_store.structured_query("""
        MATCH (e:__Entity__)
        CALL {
            WITH e
            CALL db.index.vector.queryNodes('entity', 10, e.embedding)
            YIELD node, score
            WITH node, score
            WHERE score > toFLoat($cutoff)
                AND (toLower(node.name) CONTAINS toLower(e.name) OR toLower(e.name) CONTAINS toLower(node.name)
                    OR apoc.text.distance(toLower(node.name), toLower(e.name)) < $distance)
                AND labels(e) = labels(node)
            WITH node, score
            ORDER BY node.name
            RETURN collect(node) AS nodes
        }
        WITH distinct nodes
        WHERE size(nodes) > 1
        WITH collect([n in nodes | n.name]) AS results
        UNWIND range(0, size(results)-1, 1) as index
        WITH results, index, results[index] as result
        WITH apoc.coll.sort(reduce(acc = result, index2 IN range(0, size(results)-1, 1) |
                CASE WHEN index <> index2 AND
                    size(apoc.coll.intersection(acc, results[index2])) > 0
                    THEN apoc.coll.union(acc, results[index2])
                    ELSE acc
                END
        )) as combinedResult
        WITH distinct(combinedResult) as combinedResult
        // extra filtering
        WITH collect(combinedResult) as allCombinedResults
        UNWIND range(0, size(allCombinedResults)-1, 1) as combinedResultIndex
        WITH allCombinedResults[combinedResultIndex] as combinedResult, combinedResultIndex, allCombinedResults
        WHERE NOT any(x IN range(0,size(allCombinedResults)-1,1)
            WHERE x <> combinedResultIndex
            AND apoc.coll.containsAll(allCombinedResults[x], combinedResult)
        )
        CALL {
            WITH combinedResult
            UNWIND combinedResult AS name
            MATCH (e:__Entity__ {name:name})
            WITH e
            ORDER BY size(e.name) DESC // prefer longer names to remain after merging
            RETURN collect(e) AS nodes
        }
        CALL apoc.refactor.mergeNodes(nodes, {properties: {
            `.*`: 'discard'
        }})
        YIELD node
        RETURN count(*)
        """, param_map={'cutoff': similarity_threshold, 'distance': word_edit_distance})

    except Exception as e:
        logging.error("Error during entity deduplication: %s", e)
        raise

# Only run load_and_create_index if there are nodes in the graph store
if has_nodes:
    print("Graph store already populated, skipping index creation.")

    # run this if index is already loaded
    index = PropertyGraphIndex.from_existing(
        graph_store,
        show_progress=True,
    )

else:
    print("Graph store is empty, proceeding with index creation.")
  
    directory_path = "./data/"

    index = load_and_create_index(directory_path, graph_store, persist_dir="./storage")
    # Perform entity deduplication
    entity_deduplication(graph_store)
    
    if index:
        print("Index successfully created and stored.")
    else:
        print("Index creation failed or no sub-documents were found.") 


def fetch_details(user_question):
    """
    Set up vector retrievers and query agent to retrieve information on Process Flow Diagrams (PFDs) 
    and Piping and Instrumentation Diagrams (P&IDs) based on the user question.
    
    Args:
        user_question (str): The user's question to query the system.
        index (PropertyGraphIndex): Property graph index to retrieve from.
        embed_model (OpenAIEmbedding): Embedding model for vectorization.
        llm: Large Language Model used to generate responses.
    
    Returns:
        str: The generated response from the agent based on the user question.
    """
    
    try:
        # Step 1: Set up the KG vector retriever
        def setup_vector_retriever(index):
            """Set up and return a vector retriever for the given index and embedding model."""
            try:
                return VectorContextRetriever(
                    index.property_graph_store,
                    embed_model=Settings.embed_model,
                    similarity_top_k=4,
                    path_depth=1,
                    include_text=True,
                )
            except Exception as e:
                logging.error("Error setting up vector retriever: %s", e)
                raise

        # Step 2: Custom retriever class that combines KG and direct vector search
        class CustomRetriever(BaseRetriever):
            """Custom retriever that performs both KG vector search and direct vector search."""
            def __init__(self, kg_retriever, vector_retriever):
                self._kg_retriever = kg_retriever
                self._vector_retriever = vector_retriever

            def _retrieve(self, query_bundle) -> List[NodeWithScore]:
                """Retrieve nodes given a query bundle, combining KG and vector results."""
                try:
                    kg_nodes = self._kg_retriever.retrieve(query_bundle)
                    vector_nodes = self._vector_retriever.retrieve(query_bundle)

                    unique_nodes = {n.node_id: n for n in kg_nodes}
                    unique_nodes.update({n.node_id: n for n in vector_nodes})
                    return list(unique_nodes.values())
                except Exception as e:
                    logging.error("Error during retrieval: %s", e)
                    raise

        # Step 3: Set up the KG retriever and base vector retriever
        kg_retriever = setup_vector_retriever(index)
        sub_docs = load_sub_docs("sub_docs.pkl")
        base_retriever = VectorStoreIndex.from_documents(sub_docs, embed_model=Settings.embed_model).as_retriever(similarity_top_k=4)
        custom_retriever = CustomRetriever(kg_retriever, base_retriever)

        # Step 4: Build the agent with the custom retriever
        kg_query_engine = RetrieverQueryEngine(custom_retriever)
        kg_query_tool = QueryEngineTool(
            query_engine=kg_query_engine,
            metadata=ToolMetadata(
                name="query_tool",
                description="Provides information on Process Flow Diagrams (PFDs) and Piping and Instrumentation Diagrams (P&IDs) used in industrial-scale chemical production.",
            ),
        )
        agent_worker = FunctionCallingAgentWorker.from_tools(
            [kg_query_tool],
            llm=Settings.llm,
            verbose=True,
            allow_parallel_tool_calls=False,
        )
        agent = agent_worker.as_agent()

        # Step 5: Run the agent with the user's question
        response = agent.chat(user_question)
        return response
    except Exception as e:
        logging.error("Error during agent response generation: %s", e)
        raise

# Example question
user_question = "Describe the Process Flow Diagram (PFD) of Fipronil production?"
# Call the function
response = fetch_details(user_question)
print(response)


