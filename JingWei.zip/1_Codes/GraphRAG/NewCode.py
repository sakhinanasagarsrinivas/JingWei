

# pip install pubchempy
# pip install rdkit==2024.3.5

# To display all relationships in a Neo4j database
'''
MATCH (n)-[r]->(m)
RETURN n, r, m
'''

# To delete all nodes in a Neo4j database using Cypher, you can use the following query:
''' 
MATCH (n)
DETACH DELETE n;
'''

import warnings
warnings.filterwarnings('ignore')

import os
import sys
import json
import pickle
import logging
# Suppress Neo4j warning logs
logging.getLogger("neo4j.notifications").setLevel(logging.ERROR)

import requests
from typing import List
from neo4j import GraphDatabase
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from llama_parse import LlamaParse
from copy import deepcopy
from llama_index.llms.ollama import Ollama
from llama_index.core.schema import Document
from llama_index.core.indices.property_graph import (
    ImplicitPathExtractor,
    SimpleLLMPathExtractor,
)
from llama_index.core import PropertyGraphIndex
from llama_index.graph_stores.neo4j import Neo4jPGStore
from llama_index.core import VectorStoreIndex
from llama_index.core.indices.property_graph import VectorContextRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.agent import FunctionCallingAgentWorker
from requests.exceptions import ConnectionError, Timeout

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

# #####################################################################

#############  Setup Model
# Define or load your LLM
import openai
import pandas as pd

# Set up API keys and LLM settings
os.environ['OPENAI_API_KEY'] = ''
# Example usage
gpt4_client = openai.OpenAI(api_key="")    


llm = OpenAI(model="gpt-4o-mini", temperature=0.2, max_tokens=4096, top_p=1.0, frequency_penalty=0.0, presence_penalty=0.0)
embed_model = OpenAIEmbedding(model="text-embedding-3-small")

Settings.llm = llm
Settings.embed_model = embed_model
# Settings.chunk_size = 1024
# Settings.chunk_overlap = 512

#####################################################################

'''
Auxiliary Functions
'''

def load_sub_docs(file_name):
    """Load sub-documents from a file."""
    try:
        with open(file_name, "rb") as f:
            return pickle.load(f)
    except IOError as e:
        logging.error("Error loading sub-documents from file: %s", e)
        raise


def setup_graph_store():
    """Initialize and return a connection to the Neo4j property graph store, and check if it already has nodes."""

    # Credentials for Neo4j
    neo4j_url = "neo4j+s://4ec5c2b0.databases.neo4j.io"
    neo4j_username = "neo4j"
    neo4j_password = "kJsI9hcuzSqYb4wO-eIJRrZ1ss0zF1HhFjQlVcGce2k"

    try:
        # Establish a direct connection to the Neo4j database using the Neo4j driver
        driver = GraphDatabase.driver(neo4j_url, auth=(neo4j_username, neo4j_password))

        # Check if the graph store already has nodes
        with driver.session() as session:
            cypher_query = "MATCH (n) RETURN count(n) AS node_count LIMIT 1"
            result = session.run(cypher_query)
            node_count = result.single()["node_count"]

            if node_count > 0:
                logging.info(f"Graph store already contains {node_count} nodes.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url,), True  # Return the driver and flag indicating the graph has nodes
            else:
                logging.info("Graph store is empty. No nodes found.")
                return Neo4jPGStore(username=neo4j_username, password=neo4j_password, url=neo4j_url,), False  # Return the driver and flag indicating the graph is empty

    except ConnectionError as e:
        logging.error("Failed to connect to Neo4j graph store: %s", e)
        raise
    except TimeoutError as e:
        logging.error("Connection to Neo4j graph store timed out: %s", e)
        raise
    except Exception as e:
        logging.error("An error occurred while checking the graph store: %s", e)
        raise

# Initialize graph store and check if it has nodes
graph_store, has_nodes = setup_graph_store()

# Only run load_and_create_index if there are nodes in the graph store
if has_nodes:
    print("Graph store already populated, skipping index creation.")

    # run this if index is already loaded
    index = PropertyGraphIndex.from_existing(
        graph_store,
        show_progress=True,
    )

def fetch_details(user_question):
    """
    Set up vector retrievers and query agent to retrieve information on Process Flow Diagrams (PFDs) 
    and Piping and Instrumentation Diagrams (P&IDs) based on the user question.
    
    Args:
        user_question (str): The user's question to query the system.
        index (PropertyGraphIndex): Property graph index to retrieve from.
        embed_model (OpenAIEmbedding): Embedding model for vectorization.
        llm: Large Language Model used to generate responses.
    
    Returns:
        str: The generated response from the agent based on the user question.
    """
    
    try:
        # Step 1: Set up the KG vector retriever
        def setup_vector_retriever(index):
            """Set up and return a vector retriever for the given index and embedding model."""
            try:
                return VectorContextRetriever(
                    index.property_graph_store,
                    embed_model=Settings.embed_model,
                    similarity_top_k=4,
                    path_depth=1,
                    include_text=True,
                )
            except Exception as e:
                logging.error("Error setting up vector retriever: %s", e)
                raise

        # Step 3: Set up the KG retriever and base vector retriever
        kg_retriever = setup_vector_retriever(index)

        # Step 4: Build the agent with the custom retriever
        kg_query_engine = RetrieverQueryEngine(kg_retriever)
        kg_query_tool = QueryEngineTool(
            query_engine=kg_query_engine,
            metadata=ToolMetadata(
                name="query_tool",
                description="Provides information on Process Flow Diagrams (PFDs) and Piping and Instrumentation Diagrams (P&IDs) used in industrial-scale chemical production.",
            ),
        )
        agent_worker = FunctionCallingAgentWorker.from_tools(
            [kg_query_tool],
            llm=Settings.llm,
            verbose=True,
            allow_parallel_tool_calls=False,
        )
        agent = agent_worker.as_agent()
        
        # Step 5: Run the agent with the user's question
        agent.reset()
        response = agent.chat(user_question)
        return response
    except Exception as e:
        logging.error("Error during agent response generation: %s", e)
        raise

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def generate_initial_pfd_description(query_chemical):
    """
    Generate an initial process flow diagram (PFD) description for a chemical
    using a knowledge graph to gather information from similar chemicals.

    Args:
        query_chemical (str): Name of the query molecule.

    Returns:
        str: Initial PFD description or an error message.
    """
    prompt = (
        f"Describe the process flow diagram (PFD) for {query_chemical}. "
        "Use the knowledge graph to retrieve and analyze PFDs and P&IDs of similar chemicals. "
        "Generate a detailed PFD for {query_chemical} as used in industrial-scale chemical production, "
        "highlighting any unique process steps or adjustments. Exclude unrelated details."
    )
    
    try:
        response = fetch_details(prompt)
        return response.response
    except Exception as e:
        return f"An error occurred: {e}"

def critique_pfd_description(client, pfd_description):
    """
    Critique the provided PFD description using GPT-4, focusing on technical accuracy, clarity, and completeness.

    Args:
        client (openai.Client): The OpenAI client for making API requests.
        pfd_description (str): Process Flow Diagram (PFD) description to critique.

    Returns:
        str: Critique of the PFD description from the GPT-4 model.
    """
    critique_prompt = f"""
    Evaluate the following Process Flow Diagram (PFD) description:

    {pfd_description}

    Based on the following criteria:
    1. **Technical Relevance**: Assess if the description accurately represents critical stages, unit operations, and material flows relevant to the specified chemical process. Are all necessary components and interconnections clearly outlined?

    2. **Detail and Process-Specificity**: Evaluate the level of detail provided for individual unit operations, process streams, and phase changes. ?

    Please provide constructive feedback. Exclude unrelated details.
    """
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are an expert in chemical engineering."},
            {"role": "user", "content": critique_prompt}
        ],
        temperature=0.2,
        top_p=0.7,
        max_tokens=4096,
    )
    return response.choices[0].message.content

def critique_and_refine_pfd_description(client, query_chemical, initial_pfd_description, max_iterations=1):
    """
    Iteratively critique and refine a PFD description, incorporating feedback for improvement.

    Args:
        client (openai.Client): The OpenAI client for making API requests.
        query_chemical (str): Name of the query molecule.
        initial_pfd_description (str): Initial PFD description to critique.
        max_iterations (int): Maximum number of critique and refinement iterations.

    Returns:
        str: Refined PFD description after iterative critiques.
    """
    pfd_description = initial_pfd_description
    
    for iteration in range(max_iterations):
        # Generate critique feedback
        critique_feedback = critique_pfd_description(client, pfd_description)

        # Incorporate critique feedback into the refinement prompt
        refinement_prompt = (
            f"Refine the process flow diagram (PFD) for {query_chemical} based on the following critique:\n\n{critique_feedback}\n\n"
            "Focus on:\n"
            "1. Technical Relevance: Include critical stages, unit operations, and material flows.\n"
            "2. Detail: Describe unit operations, process streams, and conditions (temperature, pressure, etc.).\n"
            "3. Clarity: Use precise, industry-standard terminology.\n"
            "Exclude unrelated details."
             )

        # Refine the PFD description with the new prompt
        try:
            refinement_response = fetch_details(refinement_prompt)
            pfd_description = refinement_response.response  # Update the description with refined version
        except Exception as e:
            return f"An error occurred while refining the description: {e}"

    return pfd_description

# Load chemical names from CSV
try:
    query_names = pd.read_csv("accepted_chemicals_new.csv")
    chemical_names = query_names['Chemical_Name'].tolist()
except Exception as e:
    print(f"Error loading CSV: {e}")
    chemical_names = []


# Generate initial descriptions and refine them
refined_descriptions = {}
for chemical in chemical_names:
    initial_description = generate_initial_pfd_description(chemical)
    refined_description = critique_and_refine_pfd_description(gpt4_client, chemical, initial_description, max_iterations=3)
    refined_descriptions[chemical] = refined_description

# Print the refined descriptions
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# Save the refined descriptions to a JSON file with each chemical name as a key
output_file = "refined_pfd_descriptions.json"
refined_descriptions_json = [{"chemical_name": chemical, "description": description} for chemical, description in refined_descriptions.items()]

try:
    with open(output_file, "w") as f:
        json.dump(refined_descriptions_json, f, indent=4)
    print(f"Refined PFD Descriptions have been saved to {output_file}")
except Exception as e:
    print(f"Error saving refined descriptions to JSON: {e}")


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





